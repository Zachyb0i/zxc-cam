import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as MemoryStick, c as HardDrive, d as Fan, f as Cpu, i as Minimize2, l as Grid2x2, n as SlidersHorizontal, o as Maximize2, r as Monitor, s as Lightbulb, u as Gauge } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DQ5ZnVj0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var BUILD = {
	cpu: {
		name: "Ryzen 9 9950X3D",
		vendor: "AMD",
		cores: 16,
		threads: 32,
		detail: "Dual CCD · 3D V-Cache",
		tdp: 170
	},
	gpu: {
		name: "GeForce RTX 5090",
		vendor: "NVIDIA",
		vram: 32,
		tdp: 575,
		bus: "PCIe 5.0 ×16",
		mem: "GDDR7"
	},
	board: {
		name: "ZXC Apex X870E",
		bios: "1.2.0.8"
	},
	ram: {
		kit: "ZXC Dominion 64 GB",
		speed: "DDR5-6400",
		timings: "CL30-39-39-76",
		sticks: 2,
		capacity: 64
	},
	cooler: "ZXC Glacier 360",
	caseName: "ZXC Prism",
	psu: "ZXC Volt 1200W",
	psuWatts: 1200
};
var DRIVES = [{
	id: "blade",
	name: "ZXC Blade",
	capacityGb: 2e3,
	used: .41,
	kind: "NVMe Gen5",
	iface: "PCIe 5.0 ×4"
}, {
	id: "vault",
	name: "ZXC Vault",
	capacityGb: 4e3,
	used: .67,
	kind: "NVMe Gen4",
	iface: "PCIe 4.0 ×4"
}];
var PROFILES = [
	{
		id: "idle",
		label: "Idle"
	},
	{
		id: "desktop",
		label: "Desktop"
	},
	{
		id: "game",
		label: "Play"
	},
	{
		id: "render",
		label: "Render"
	},
	{
		id: "stress",
		label: "Burn"
	}
];
var PRESETS = {
	silent: [
		20,
		26,
		34,
		48,
		68
	],
	balanced: [
		28,
		40,
		55,
		75,
		100
	],
	performance: [
		50,
		70,
		88,
		100,
		100
	]
};
var CURVE_TEMPS = [
	30,
	45,
	60,
	75,
	90
];
var LIGHTS = {
	cyan: "var(--color-cyan)",
	ice: "color-mix(in oklab, var(--color-cyan) 48%, var(--color-fg))",
	bone: "var(--color-fg)",
	amber: "var(--color-warn)",
	coral: "var(--color-hot)"
};
var LIGHT_KEYS = [
	"cyan",
	"ice",
	"bone",
	"amber",
	"coral"
];
var TASKS = {
	idle: [
		{
			name: "ZXC Cam",
			share: .42
		},
		{
			name: "Window manager",
			share: .36
		},
		{
			name: "System",
			share: .22
		}
	],
	desktop: [
		{
			name: "Browser",
			share: .48
		},
		{
			name: "ZXC Cam",
			share: .22
		},
		{
			name: "Music",
			share: .16
		}
	],
	game: [
		{
			name: "Aether Protocol",
			share: .72
		},
		{
			name: "Overlay",
			share: .12
		},
		{
			name: "ZXC Cam",
			share: .08
		}
	],
	render: [
		{
			name: "ZXC Render",
			share: .74
		},
		{
			name: "Encoder",
			share: .16
		},
		{
			name: "Browser",
			share: .06
		}
	],
	stress: [
		{
			name: "Burn-in CPU",
			share: .58
		},
		{
			name: "Burn-in GPU",
			share: .34
		},
		{
			name: "ZXC Cam",
			share: .05
		}
	]
};
var TARGET = {
	idle: {
		cpuL: .04,
		gpuL: .02,
		vram: 1.8,
		ram: 12.4,
		d0: .03,
		d1: .01
	},
	desktop: {
		cpuL: .14,
		gpuL: .08,
		vram: 4.6,
		ram: 21.6,
		d0: .1,
		d1: .04
	},
	game: {
		cpuL: .46,
		gpuL: .95,
		vram: 18.4,
		ram: 28.2,
		d0: .18,
		d1: .06
	},
	render: {
		cpuL: .97,
		gpuL: .48,
		vram: 10.8,
		ram: 49.5,
		d0: .62,
		d1: .16
	},
	stress: {
		cpuL: 1,
		gpuL: .99,
		vram: 27.6,
		ram: 57.4,
		d0: .78,
		d1: .28
	}
};
var DEFAULT_SETTINGS = {
	rigName: "FORGE-01",
	profile: "desktop",
	preset: "balanced",
	curve: [...PRESETS.balanced],
	cpuAlert: 90,
	gpuAlert: 85,
	effect: "breathe",
	lightSpeed: 1,
	powered: true,
	manual: false,
	manualDuty: 35,
	holdBand: true,
	rgbOn: true,
	brightness: 80,
	zones: {
		ring: {
			on: true,
			color: "cyan"
		},
		fans: {
			on: true,
			color: "cyan"
		},
		gpu: {
			on: true,
			color: "coral"
		},
		ram: {
			on: true,
			color: "ice"
		}
	}
};
function seedHistory() {
	const out = [];
	for (let i = 0; i < 72; i++) {
		const w = Math.sin(i / 8) * 1.35;
		out.push({
			cpu: 43.2 + w,
			gpu: 36.4 + w * .5,
			liquid: 31.2 + w * .22,
			cpuW: 48 + w * 2.4,
			gpuW: 52 + w * 3
		});
	}
	return out;
}
var SEEDED = seedHistory();
function createLive() {
	const history = SEEDED.map((s) => ({ ...s }));
	const last = history[history.length - 1];
	return {
		cpuLoad: .14,
		cpuTemp: last.cpu,
		cpuPower: last.cpuW,
		gpuLoad: .08,
		gpuTemp: last.gpu,
		gpuPower: last.gpuW,
		vram: 4.6,
		liquid: last.liquid,
		ramUsed: 21.6,
		fanDuty: 38,
		pump: 52,
		driveTemp: [35.5, 33.4],
		driveAct: [.08, .03],
		history,
		tick: 72,
		n1: 0,
		n2: 0,
		anchorTemp: last.cpu,
		latchedDuty: 38
	};
}
function clamp(n, a, b) {
	return Math.min(b, Math.max(a, n));
}
function lerp(a, b, t) {
	return a + (b - a) * t;
}
function sampleCurve(curve, temp) {
	const pts = CURVE_TEMPS;
	if (temp <= pts[0]) return curve[0];
	if (temp >= pts[4]) return curve[4];
	for (let i = 0; i < 4; i++) {
		const a = pts[i];
		const b = pts[i + 1];
		if (temp <= b) {
			const t = (temp - a) / (b - a);
			return curve[i] + (curve[i + 1] - curve[i]) * t;
		}
	}
	return curve[4];
}
function step(live, settings) {
	const t = TARGET[settings.profile];
	const n1 = live.n1 * .82 + (Math.random() - .5) * .18;
	const n2 = live.n2 * .82 + (Math.random() - .5) * .18;
	const cpuLoad = clamp(lerp(live.cpuLoad, t.cpuL + n1 * .035, .22), .012, 1);
	const gpuLoad = clamp(lerp(live.gpuLoad, t.gpuL + n2 * .03, .18), 0, 1);
	let dutyCmd = sampleCurve(settings.curve, live.cpuTemp);
	let anchorTemp = live.anchorTemp;
	let latchedDuty = live.latchedDuty;
	if (!settings.powered) dutyCmd = 0;
	else if (settings.manual) {
		dutyCmd = settings.manualDuty;
		latchedDuty = dutyCmd;
	} else if (settings.holdBand && Math.abs(live.cpuTemp - anchorTemp) < 3) dutyCmd = latchedDuty;
	else {
		anchorTemp = live.cpuTemp;
		latchedDuty = dutyCmd;
	}
	const fanDuty = lerp(live.fanDuty, dutyCmd, .2);
	const relief = clamp((fanDuty - 25) / 75, 0, 1) * 14;
	const cpuTarget = 36 + cpuLoad * 50 + gpuLoad * 6 + n1 * .45 - relief;
	const gpuTarget = 32 + gpuLoad * 52 + cpuLoad * 3 + n2 * .4 - relief * .35;
	const cpuTemp = clamp(lerp(live.cpuTemp, cpuTarget, .065), 28, 102);
	const gpuTemp = clamp(lerp(live.gpuTemp, gpuTarget, .07), 26, 102);
	const liquid = clamp(lerp(live.liquid, 27 + (cpuTemp - 30) * .4, .045), 24, 60);
	const cpuPower = clamp(lerp(live.cpuPower, 16 + cpuLoad * 228, .2), 8, 280);
	const gpuPower = clamp(lerp(live.gpuPower, 12 + gpuLoad * 565, .18), 8, 600);
	const vram = clamp(lerp(live.vram, t.vram, .08), .4, BUILD.gpu.vram);
	const ramUsed = clamp(lerp(live.ramUsed, t.ram, .06), 4, BUILD.ram.capacity - .4);
	const pump = clamp(lerp(live.pump, 42 + (liquid - 28) * 2.6, .08), 38, 100);
	const driveAct = [clamp(lerp(live.driveAct[0], t.d0, .2), 0, 1), clamp(lerp(live.driveAct[1], t.d1, .16), 0, 1)];
	const driveTemp = [clamp(32 + driveAct[0] * 16 + (cpuTemp - 40) * .08, 28, 72), clamp(31 + driveAct[1] * 12 + (cpuTemp - 40) * .05, 28, 68)];
	const sample = {
		cpu: cpuTemp,
		gpu: gpuTemp,
		liquid,
		cpuW: cpuPower,
		gpuW: gpuPower
	};
	return {
		cpuLoad,
		cpuTemp,
		cpuPower,
		gpuLoad,
		gpuTemp,
		gpuPower,
		vram,
		liquid,
		ramUsed,
		fanDuty,
		pump,
		driveTemp,
		driveAct,
		history: live.history.slice(1).concat(sample),
		tick: live.tick + 1,
		n1,
		n2,
		anchorTemp,
		latchedDuty
	};
}
function cpuGhz(load, temp) {
	let ghz;
	if (load < .08) ghz = 3.25 + load * 6;
	else if (load < .35) ghz = 5.15 + (.35 - load) * 1.5;
	else ghz = 5.22 - (load - .35) * .48;
	if (temp > 93) ghz -= (temp - 93) * .07;
	return clamp(ghz, 2.6, 5.7);
}
function fanRpm(duty, max, tick, phase) {
	const wobble = Math.sin(tick / 5 + phase) * 14;
	return Math.max(0, Math.round(duty / 100 * max + wobble));
}
function snapshot(live, settings) {
	const cpuClock = cpuGhz(live.cpuLoad, live.cpuTemp);
	const gpuClock = live.gpuLoad < .08 ? 210 + live.gpuLoad * 800 : clamp(2520 + live.gpuLoad * 220 - Math.max(0, live.gpuTemp - 84) * 22, 400, 2790);
	const memClock = live.gpuLoad < .08 ? 405 : 2235;
	const hotspot = live.gpuTemp + 8 + live.gpuLoad * 8;
	const memJunction = live.gpuTemp + 3 + live.gpuLoad * 12;
	const vcore = clamp(1.02 + live.cpuLoad * .27 - Math.max(0, live.cpuTemp - 90) * .01, .9, 1.38);
	const cores = Array.from({ length: 16 }, (_, i) => {
		const wave = Math.sin(live.tick / 7 + i * .65);
		const load = clamp(live.cpuLoad + (i < 8 ? .05 : -.03) + wave * .035, .01, 1);
		const temp = live.cpuTemp + (i < 8 ? 3.4 : -1.6) + wave * 1.15;
		return {
			index: i,
			load,
			temp,
			clock: clamp(cpuClock + i % 4 * .015 - (temp > 94 ? .12 : 0), 2.4, 5.75),
			ccd: i < 8 ? 0 : 1
		};
	});
	const hottest = cores.reduce((best, core) => core.temp > best.temp ? core : best, cores[0]);
	const fans = [
		{
			id: "r1",
			name: "Radiator 1",
			role: "Intake",
			rpm: fanRpm(live.fanDuty, 1800, live.tick, 0),
			max: 1800
		},
		{
			id: "r2",
			name: "Radiator 2",
			role: "Intake",
			rpm: fanRpm(live.fanDuty, 1800, live.tick, 1.1),
			max: 1800
		},
		{
			id: "r3",
			name: "Radiator 3",
			role: "Intake",
			rpm: fanRpm(live.fanDuty, 1800, live.tick, 2.2),
			max: 1800
		},
		{
			id: "ex",
			name: "Rear exhaust",
			role: "Exhaust",
			rpm: fanRpm(live.fanDuty * .92, 1600, live.tick, .5),
			max: 1600
		}
	];
	const gpuFanOn = live.gpuTemp > 50 || live.gpuLoad > .2;
	const gpuFanDuty = gpuFanOn ? clamp((live.gpuTemp - 42) / 42, .28, 1) : 0;
	return {
		cpuClock,
		gpuClock,
		memClock,
		hotspot,
		memJunction,
		vcore,
		cores,
		hottest,
		fans,
		gpuFanOn,
		gpuFanRpm: gpuFanOn ? Math.round(gpuFanDuty * 2200 + Math.sin(live.tick / 4) * 18) : 0,
		gpuFanDuty,
		pumpRpm: Math.round(1450 + live.pump / 100 * 1500),
		sysPower: live.cpuPower + live.gpuPower + 28 + live.ramUsed * .12,
		tasks: TASKS[settings.profile].map((task, i) => {
			const wobble = .92 + .08 * Math.sin(live.tick / 6 + i);
			return {
				name: task.name,
				cpu: clamp(task.share * live.cpuLoad * 100 * wobble, 0, 100)
			};
		}),
		drives: DRIVES.map((drive, i) => {
			const act = live.driveAct[i];
			const swing = .55 + .45 * (.5 + .5 * Math.sin(live.tick / 8 + i));
			const scale = i === 0 ? 1 : .62;
			return {
				...drive,
				temp: live.driveTemp[i],
				activity: act,
				read: act * 4200 * scale,
				write: act * 2800 * scale * swing
			};
		}),
		uptime: 15120 + live.tick * .4,
		delta: live.cpuTemp - live.history[0].cpu,
		gpuDelta: live.gpuTemp - live.history[0].gpu
	};
}
function formatUptime(seconds) {
	const s = Math.max(0, Math.floor(seconds));
	const h = Math.floor(s / 3600);
	const m = Math.floor(s % 3600 / 60);
	const sec = s % 60;
	return `${h}h ${String(m).padStart(2, "0")}m ${String(sec).padStart(2, "0")}s`;
}
function toneOf(temp) {
	if (temp <= 47) return "cyan";
	if (temp <= 78) return "warn";
	return "hot";
}
function toneStroke(temp) {
	const tone = toneOf(temp);
	if (tone === "cyan") return "var(--color-cyan)";
	if (tone === "warn") return "var(--color-warn)";
	return "var(--color-hot)";
}
function toneText(temp) {
	const tone = toneOf(temp);
	if (tone === "cyan") return "text-cyan";
	if (tone === "warn") return "text-warn";
	return "text-hot";
}
function toneBar(temp) {
	const tone = toneOf(temp);
	if (tone === "cyan") return "bg-cyan";
	if (tone === "warn") return "bg-warn";
	return "bg-hot";
}
var PROFILES_SET = new Set(PROFILES.map((p) => p.id));
var PRESET_SET = /* @__PURE__ */ new Set([
	"silent",
	"balanced",
	"performance",
	"custom"
]);
var EFFECT_SET = /* @__PURE__ */ new Set([
	"solid",
	"breathe",
	"wave",
	"chase"
]);
var LIGHT_SET = new Set(LIGHT_KEYS);
function zone(value, fallback) {
	if (!value || typeof value !== "object") return fallback;
	const z = value;
	return {
		on: typeof z.on === "boolean" ? z.on : fallback.on,
		color: typeof z.color === "string" && LIGHT_SET.has(z.color) ? z.color : fallback.color
	};
}
function sanitizeSettings(raw) {
	const base = DEFAULT_SETTINGS;
	if (!raw || typeof raw !== "object") return base;
	const p = raw;
	const curveOk = Array.isArray(p.curve) && p.curve.length === 5 && p.curve.every((n) => typeof n === "number" && n >= 0 && n <= 100);
	const zones = p.zones ?? {};
	return {
		rigName: typeof p.rigName === "string" && p.rigName.trim() ? p.rigName.trim().slice(0, 18) : base.rigName,
		profile: typeof p.profile === "string" && PROFILES_SET.has(p.profile) ? p.profile : base.profile,
		preset: typeof p.preset === "string" && PRESET_SET.has(p.preset) ? p.preset : base.preset,
		curve: curveOk ? p.curve : base.curve,
		cpuAlert: typeof p.cpuAlert === "number" ? clamp(p.cpuAlert, 70, 105) : base.cpuAlert,
		gpuAlert: typeof p.gpuAlert === "number" ? clamp(p.gpuAlert, 70, 105) : base.gpuAlert,
		effect: typeof p.effect === "string" && EFFECT_SET.has(p.effect) ? p.effect : base.effect,
		lightSpeed: typeof p.lightSpeed === "number" ? clamp(p.lightSpeed, .5, 2) : base.lightSpeed,
		powered: typeof p.powered === "boolean" ? p.powered : base.powered,
		manual: typeof p.manual === "boolean" ? p.manual : base.manual,
		manualDuty: typeof p.manualDuty === "number" ? clamp(p.manualDuty, 0, 100) : base.manualDuty,
		holdBand: typeof p.holdBand === "boolean" ? p.holdBand : base.holdBand,
		rgbOn: typeof p.rgbOn === "boolean" ? p.rgbOn : base.rgbOn,
		brightness: typeof p.brightness === "number" ? clamp(p.brightness, 0, 100) : base.brightness,
		zones: {
			ring: zone(zones.ring, base.zones.ring),
			fans: zone(zones.fans, base.zones.fans),
			gpu: zone(zones.gpu, base.zones.gpu),
			ram: zone(zones.ram, base.zones.ram)
		}
	};
}
var KEY = "zxc-cam-v1";
var RigContext = (0, import_react.createContext)(null);
function RigProvider({ children }) {
	const [live, setLive] = (0, import_react.useState)(() => createLive());
	const [settings, setSettings] = (0, import_react.useState)(DEFAULT_SETTINGS);
	const [view, setView] = (0, import_react.useState)("overview");
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const settingsRef = (0, import_react.useRef)(settings);
	settingsRef.current = settings;
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(KEY);
			if (raw) setSettings(sanitizeSettings(JSON.parse(raw)));
		} catch {}
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		localStorage.setItem(KEY, JSON.stringify(settings));
	}, [settings, hydrated]);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => {
			setLive((prev) => step(prev, settingsRef.current));
		}, 400);
		return () => window.clearInterval(id);
	}, []);
	const value = (0, import_react.useMemo)(() => {
		const snap = snapshot(live, settings);
		return {
			live,
			settings,
			snap,
			view,
			setView,
			setProfile: (profile) => setSettings((s) => ({
				...s,
				profile
			})),
			setRigName: (name) => setSettings((s) => ({
				...s,
				rigName: name.slice(0, 18)
			})),
			applyPreset: (preset) => setSettings((s) => ({
				...s,
				manual: false,
				preset,
				curve: [...PRESETS[preset]]
			})),
			setCurvePoint: (index, point) => setSettings((s) => {
				const curve = [...s.curve];
				curve[index] = point;
				return {
					...s,
					curve,
					preset: "custom",
					manual: false
				};
			}),
			setAlerts: (cpu, gpu) => setSettings((s) => ({
				...s,
				cpuAlert: cpu,
				gpuAlert: gpu
			})),
			setEffect: (effect) => setSettings((s) => ({
				...s,
				effect
			})),
			setLightSpeed: (lightSpeed) => setSettings((s) => ({
				...s,
				lightSpeed
			})),
			setZone: (id, patch) => setSettings((s) => ({
				...s,
				zones: {
					...s.zones,
					[id]: {
						...s.zones[id],
						...patch
					}
				}
			})),
			setPowered: (powered) => setSettings((s) => ({
				...s,
				powered
			})),
			setRpm: (mode) => setSettings((s) => {
				if (mode === "manual") return {
					...s,
					manual: true
				};
				if (mode === "custom") return {
					...s,
					manual: false,
					preset: "custom"
				};
				const preset = mode === "low" ? "silent" : mode === "med" ? "balanced" : "performance";
				return {
					...s,
					manual: false,
					preset,
					curve: [...PRESETS[preset]]
				};
			}),
			setManualDuty: (manualDuty) => setSettings((s) => ({
				...s,
				manual: true,
				manualDuty
			})),
			setHoldBand: (holdBand) => setSettings((s) => ({
				...s,
				holdBand
			})),
			setRgbOn: (rgbOn) => setSettings((s) => ({
				...s,
				rgbOn
			})),
			setBrightness: (brightness) => setSettings((s) => ({
				...s,
				brightness
			})),
			resetTuning: () => setSettings((s) => ({
				...DEFAULT_SETTINGS,
				rigName: s.rigName,
				profile: s.profile,
				zones: {
					ring: { ...DEFAULT_SETTINGS.zones.ring },
					fans: { ...DEFAULT_SETTINGS.zones.fans },
					gpu: { ...DEFAULT_SETTINGS.zones.gpu },
					ram: { ...DEFAULT_SETTINGS.zones.ram }
				},
				curve: [...DEFAULT_SETTINGS.curve]
			}))
		};
	}, [
		live,
		settings,
		view
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RigContext.Provider, {
		value,
		children
	});
}
function useRig() {
	const ctx = (0, import_react.useContext)(RigContext);
	if (!ctx) throw new Error("useRig must be used inside RigProvider");
	return ctx;
}
function FanGlyph({ rpm, max, className = "" }) {
	const ratio = Math.max(0, Math.min(1, max > 0 ? rpm / max : 0));
	const dur = rpm < 40 ? 0 : Math.max(.32, 2.3 - ratio * 1.95);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 64",
		className: `text-current ${className}`,
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "32",
				r: "29",
				fill: "none",
				stroke: "currentColor",
				strokeOpacity: "0.4",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
				className: dur ? "fan-spin" : void 0,
				style: dur ? { animationDuration: `${dur}s` } : void 0,
				children: Array.from({ length: 7 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M32 33c4-8 5-16 0-20c-5 4-4 12 0 20z",
					fill: "currentColor",
					transform: `rotate(${i * (360 / 7)} 32 32)`
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "32",
				r: "5",
				fill: "var(--color-bg)",
				stroke: "currentColor",
				strokeWidth: "1.6"
			})
		]
	});
}
function Panel({ className = "", children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: `panel ${className}`,
		children
	});
}
function Eyebrow({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs font-medium tracking-widest text-muted uppercase",
		children
	});
}
function Metric({ label, value, unit, tone = "text-fg" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: `mt-1 font-mono text-xl tabular-nums leading-none ${tone}`,
			children: [value, unit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ml-1 font-sans text-xs tracking-normal text-muted",
				children: unit
			}) : null]
		})]
	});
}
function Bar({ value, tone = "bg-cyan", label }) {
	const width = Math.max(0, Math.min(100, value));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-2 overflow-hidden rounded-full bg-bg",
		role: "meter",
		"aria-valuenow": Math.round(width),
		"aria-valuemin": 0,
		"aria-valuemax": 100,
		"aria-label": label,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `h-full rounded-full ${tone}`,
			style: { width: `${width}%` }
		})
	});
}
var PRESET_LIST = [
	{
		id: "silent",
		label: "Silent"
	},
	{
		id: "balanced",
		label: "Balanced"
	},
	{
		id: "performance",
		label: "Performance"
	}
];
function Cooling() {
	const { live, settings, snap, applyPreset, setCurvePoint } = useRig();
	const dutyNow = sampleCurve(settings.curve, live.cpuTemp);
	const points = settings.curve.map((duty, i) => {
		return `${i / 4 * 100},${100 - duty}`;
	}).join(" ");
	const marker = Math.max(0, Math.min(100, (live.cpuTemp - 30) / 60 * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					className: "p-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Coolant",
						value: live.liquid.toFixed(1),
						unit: "°C",
						tone: toneText(live.liquid)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					className: "p-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "CPU − liquid",
						value: (live.cpuTemp - live.liquid).toFixed(1),
						unit: "Δ°"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					className: "p-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Pump",
						value: String(snap.pumpRpm),
						unit: `${Math.round(live.pump)}%`
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: snap.fans.map((fan) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: "flex items-center gap-3 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-cyan",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FanGlyph, {
							rpm: fan.rpm,
							max: fan.max,
							className: "size-16"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: fan.role }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 truncate text-sm text-fg",
								children: fan.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-lg tabular-nums text-fg",
								children: [fan.rpm, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-1 text-xs text-muted",
									children: "RPM"
								})]
							})
						]
					})]
				}, fan.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Fan curve" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								"Duty ",
								Math.round(dutyNow),
								"% at ",
								live.cpuTemp.toFixed(0),
								"° package",
								settings.preset === "custom" ? " · custom" : ""
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							role: "group",
							"aria-label": "Fan preset",
							children: PRESET_LIST.map((preset) => {
								const on = settings.preset === preset.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": on,
									onClick: () => applyPreset(preset.id),
									className: `press h-11 rounded-control border px-3 text-sm ${on ? "border-cyan text-cyan" : "border-line text-muted"}`,
									children: preset.label
								}, preset.id);
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						viewBox: "0 0 100 100",
						className: "mt-4 h-40 w-full",
						preserveAspectRatio: "none",
						"aria-hidden": true,
						children: [
							[
								25,
								50,
								75
							].map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: "0",
								x2: "100",
								y1: y,
								y2: y,
								stroke: "var(--color-line)",
								strokeWidth: "0.6"
							}, y)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
								points: `0,100 ${points} 100,100`,
								fill: "var(--color-cyan)",
								opacity: "0.16"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
								points,
								fill: "none",
								stroke: "var(--color-cyan)",
								strokeWidth: "1.6",
								vectorEffect: "non-scaling-stroke"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: marker,
								x2: marker,
								y1: "0",
								y2: "100",
								stroke: "var(--color-warn)",
								strokeWidth: "0.8"
							}),
							settings.curve.map((duty, i) => {
								const x = i / 4 * 100;
								const y = 100 - duty;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
									x1: x,
									x2: x,
									y1: y - 3,
									y2: y + 3,
									stroke: "var(--color-fg)",
									strokeWidth: "2",
									vectorEffect: "non-scaling-stroke"
								}, CURVE_TEMPS[i]);
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 grid grid-cols-5 font-mono text-xs text-muted tabular-nums",
						children: CURVE_TEMPS.map((temp) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-center",
							children: [temp, "°"]
						}, temp))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 grid gap-1 sm:grid-cols-5",
						children: settings.curve.map((duty, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mb-1 block text-center font-mono text-xs tabular-nums text-fg",
								children: [Math.round(duty), "%"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "duty",
								type: "range",
								min: 15,
								max: 100,
								value: Math.round(duty),
								"aria-label": `Fan duty at ${CURVE_TEMPS[i]} degrees`,
								onChange: (e) => setCurvePoint(i, Number(e.target.value))
							})]
						}, CURVE_TEMPS[i]))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							"Balanced is ",
							PRESETS.balanced.join(" / "),
							"%. Higher duty pulls package temperature down — the loop has mass, so give it a few seconds."
						]
					})
				]
			})]
		})]
	});
}
function TraceSlot({ series = "both" }) {
	const ref = (0, import_react.useRef)(null);
	const [width, setWidth] = (0, import_react.useState)(0);
	const [mod, setMod] = (0, import_react.useState)(null);
	const [mode, setMode] = (0, import_react.useState)("temp");
	(0, import_react.useEffect)(() => {
		let on = true;
		import("./trace-chart-CRnRe_vq.mjs").then((m) => {
			if (on) setMod(m);
		});
		return () => {
			on = false;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		const apply = () => setWidth(Math.floor(el.clientWidth));
		apply();
		const ro = new ResizeObserver(apply);
		ro.observe(el);
		return () => ro.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "p-4 sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Trace · 30 seconds" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: mode === "temp" ? "Package temperature" : "Board power"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [
					series !== "gpu" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5 text-xs text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-cyan" }), " CPU"]
					}) : null,
					series !== "cpu" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5 text-xs text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-hot" }), " GPU"]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex rounded-control border border-line p-1",
						role: "group",
						"aria-label": "Trace mode",
						children: ["temp", "power"].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": mode === id,
							onClick: () => setMode(id),
							className: `press h-9 rounded-md px-3 text-xs font-medium tracking-wide uppercase ${mode === id ? "bg-raised text-fg" : "text-muted"}`,
							children: id === "temp" ? "Temp" : "Power"
						}, id))
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref,
			className: "mt-3 h-52 w-full min-w-0",
			children: mod && width > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(mod.TraceChart, {
				width,
				height: 208,
				mode,
				series
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full" })
		})]
	});
}
function CpuView() {
	const { live, snap } = useRig();
	const groups = [{
		id: "CCD0",
		note: "3D V-Cache",
		cores: snap.cores.filter((c) => c.ccd === 0)
	}, {
		id: "CCD1",
		note: "Frequency",
		cores: snap.cores.filter((c) => c.ccd === 1)
	}];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						className: "p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
							label: "Package",
							value: live.cpuTemp.toFixed(1),
							unit: "°C",
							tone: toneText(live.cpuTemp)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						className: "p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
							label: "Effective",
							value: snap.cpuClock.toFixed(2),
							unit: "GHz"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						className: "p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
							label: "Vcore",
							value: snap.vcore.toFixed(3),
							unit: "V"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						className: "p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
							label: "Power",
							value: Math.round(live.cpuPower).toString(),
							unit: `/ ${BUILD.cpu.tdp} W TDP`
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: "p-4 sm:p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: group.id }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: group.note
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4",
						children: group.cores.map((core) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-control border border-line bg-bg p-2.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono text-xs text-muted",
										children: ["C", String(core.index).padStart(2, "0")]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono text-xs tabular-nums text-muted",
										children: [Math.round(core.load * 100), "%"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: `mt-2 font-mono text-2xl tabular-nums leading-none ${toneText(core.temp)}`,
									children: [Math.round(core.temp), "°"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 font-mono text-xs tabular-nums text-muted",
									children: [core.clock.toFixed(2), " GHz"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										value: core.load * 100,
										tone: toneBar(core.temp),
										label: `Core ${core.index}`
									})
								})
							]
						}, core.index))
					})]
				}, group.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TraceSlot, { series: "cpu" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					BUILD.cpu.vendor,
					" ",
					BUILD.cpu.name,
					" · socket AM5 · ",
					BUILD.cpu.cores,
					" cores / ",
					BUILD.cpu.threads,
					" threads. CCD0 carries the stacked cache and runs a few degrees warmer."
				]
			})
		]
	});
}
function GpuView() {
	const { live, snap } = useRig();
	const powerPct = live.gpuPower / BUILD.gpu.tdp * 100;
	const vramPct = live.vram / BUILD.gpu.vram * 100;
	const blocks = 16;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Thermals" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid grid-cols-3 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "Edge",
								value: live.gpuTemp.toFixed(1),
								unit: "°",
								tone: toneText(live.gpuTemp)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "Hotspot",
								value: snap.hotspot.toFixed(1),
								unit: "°",
								tone: toneText(snap.hotspot)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "Memory",
								value: snap.memJunction.toFixed(1),
								unit: "°",
								tone: toneText(snap.memJunction)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex items-baseline justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Power limit" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-sm tabular-nums text-fg",
								children: [
									Math.round(live.gpuPower),
									" / ",
									BUILD.gpu.tdp,
									" W"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
							value: powerPct,
							tone: powerPct > 92 ? "bg-hot" : "bg-cyan",
							label: "GPU power"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 grid grid-cols-2 gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
							label: "Core clock",
							value: Math.round(snap.gpuClock).toString(),
							unit: "MHz"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
							label: "Memory clock",
							value: Math.round(snap.memClock).toString(),
							unit: "MHz"
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "flex flex-col gap-5 p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: snap.gpuFanOn ? "text-cyan" : "text-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FanGlyph, {
								rpm: snap.gpuFanRpm,
								max: 2200,
								className: "size-20"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Cooler" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 font-mono text-2xl tabular-nums text-fg",
								children: [snap.gpuFanRpm, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-1 text-xs text-muted",
									children: "RPM"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: snap.gpuFanOn ? "Fans tracking hotspot" : "Fan stop · under light load"
							})
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex items-baseline justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "VRAM" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-sm tabular-nums text-muted",
								children: [
									live.vram.toFixed(1),
									" / ",
									BUILD.gpu.vram,
									" GB"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-8 gap-1",
							"aria-hidden": true,
							children: Array.from({ length: blocks }, (_, i) => {
								const filled = (i + 1) / blocks <= vramPct / 100 + .001;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-8 rounded-sm ${filled ? "bg-cyan" : "bg-bg"}` }, i);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs text-muted",
							children: [
								BUILD.gpu.mem,
								" · ",
								BUILD.gpu.bus
							]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3 border-t border-line pt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
							label: "Load",
							value: `${Math.round(live.gpuLoad * 100)}`,
							unit: "%"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-widest text-muted uppercase",
								children: "Board"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-fg",
								children: BUILD.gpu.vendor
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: BUILD.gpu.name
							})
						] })]
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TraceSlot, { series: "gpu" })]
	});
}
function glowStyle(on, color, effect, speed, delay, lit, brightness) {
	if (!on || !lit) return { color: "var(--color-muted)" };
	return {
		color,
		borderColor: color,
		boxShadow: `0 0 22px color-mix(in oklab, ${color} ${Math.max(12, Math.round(brightness * .55))}%, transparent)`,
		animationDuration: effect === "solid" ? void 0 : `${(2.8 / (effect === "chase" ? speed * 1.6 : speed)).toFixed(2)}s`,
		animationDelay: effect === "wave" || effect === "chase" ? delay : void 0
	};
}
function CaseTower({ settings, snap }) {
	const lit = settings.rgbOn && settings.powered && settings.brightness > 0;
	const motion = lit && settings.effect !== "solid" ? "fx-breathe" : "";
	const ringOn = settings.zones.ring.on && lit;
	const fansOn = settings.zones.fans.on && lit;
	const gpuOn = settings.zones.gpu.on && lit;
	const ramOn = settings.zones.ram.on && lit;
	const glow = (on, color, delay) => glowStyle(on, color, settings.effect, settings.lightSpeed, delay, lit, settings.brightness);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "chassis",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "chassis-shell",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "chassis-mesh" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "chassis-led" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "chassis-bay",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-3 gap-1",
								children: snap.fans.slice(0, 3).map((fan) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `flex items-center justify-center rounded-lg border border-line p-1 ${fansOn ? motion : "opacity-40"}`,
									style: glow(fansOn, LIGHTS[settings.zones.fans.color], "0.35s"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FanGlyph, {
										rpm: fan.rpm,
										max: fan.max,
										className: "size-10 sm:size-12"
									})
								}, fan.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-1 items-center gap-3 px-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `grid size-16 place-items-center rounded-full border-2 sm:size-20 ${ringOn ? motion : "opacity-40"}`,
									style: glow(ringOn, LIGHTS[settings.zones.ring.color], "0s"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-medium tracking-widest",
										children: "CPU"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex h-16 gap-1 sm:h-20",
									children: [0, 1].map((stick) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `w-3 rounded-sm border sm:w-4 ${ramOn ? motion : "opacity-40"}`,
										style: glow(ramOn, LIGHTS[settings.zones.ram.color], "1.05s")
									}, stick))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `flex h-12 items-center rounded-md border px-3 ${gpuOn ? motion : "opacity-40"}`,
								style: glow(gpuOn, LIGHTS[settings.zones.gpu.color], "0.7s"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-medium tracking-widest",
									children: "GPU"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-auto font-mono text-xs tabular-nums",
									children: snap.gpuFanRpm > 0 ? snap.gpuFanRpm : "STOP"
								})]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "foot foot-l" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "foot foot-r" })
		]
	});
}
var EFFECTS = [
	{
		id: "solid",
		label: "Solid"
	},
	{
		id: "breathe",
		label: "Breathe"
	},
	{
		id: "wave",
		label: "Wave"
	},
	{
		id: "chase",
		label: "Color Chase"
	}
];
var ZONES = [
	{
		id: "ring",
		label: "Pump ring",
		hint: "Cold plate"
	},
	{
		id: "fans",
		label: "Radiator",
		hint: "Three rings"
	},
	{
		id: "gpu",
		label: "Graphics",
		hint: "Edge accent"
	},
	{
		id: "ram",
		label: "Memory",
		hint: "Both DIMMs"
	}
];
var NAMES = {
	cyan: "Voltage",
	ice: "Ice",
	bone: "Bone",
	amber: "Amber",
	coral: "Coral"
};
function Lighting() {
	const { settings, snap, setEffect, setLightSpeed, setZone } = useRig();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid items-start gap-4 lg:grid-cols-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "p-4 lg:col-span-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Prism" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Live preview of the zones on FORGE-01."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CaseTower, {
						settings,
						snap
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 flex-col gap-4 lg:col-span-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Effect" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						role: "group",
						"aria-label": "Lighting effect",
						children: EFFECTS.map((effect) => {
							const on = settings.effect === effect.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": on,
								onClick: () => setEffect(effect.id),
								className: `press h-11 rounded-control border px-4 text-sm ${on ? "border-cyan bg-cyan text-bg" : "border-line text-muted"}`,
								children: effect.label
							}, effect.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-5 block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center justify-between text-sm text-muted",
							children: ["Speed", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono tabular-nums text-fg",
								children: [settings.lightSpeed.toFixed(1), "×"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "duty",
							type: "range",
							min: .5,
							max: 2,
							step: .1,
							value: settings.lightSpeed,
							"aria-label": "Lighting speed",
							onChange: (e) => setLightSpeed(Number(e.target.value))
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: ZONES.map((zone) => {
					const state = settings.zones[zone.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						className: "p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium text-fg",
								children: zone.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: zone.hint
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": state.on,
								"aria-label": `${zone.label} ${state.on ? "on" : "off"}`,
								onClick: () => setZone(zone.id, { on: !state.on }),
								className: `press relative h-8 w-14 rounded-full border ${state.on ? "border-cyan bg-cyan" : "border-line bg-bg"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-1 left-0 size-5 rounded-full transition-transform duration-150 ${state.on ? "translate-x-7 bg-bg" : "translate-x-1 bg-fg"}` })
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex gap-2",
							role: "group",
							"aria-label": `${zone.label} color`,
							children: LIGHT_KEYS.map((key) => {
								const selected = state.color === key;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": NAMES[key],
									"aria-pressed": selected,
									disabled: !state.on,
									onClick: () => setZone(zone.id, { color: key }),
									className: `press size-11 rounded-full border-2 ${selected ? "border-fg" : "border-transparent"} disabled:opacity-40`,
									style: { background: LIGHTS[key] }
								}, key);
							})
						})]
					}, zone.id);
				})
			})]
		})]
	});
}
function MemoryView() {
	const { live, settings } = useRig();
	const pct = live.ramUsed / BUILD.ram.capacity * 100;
	const dimmTemp = live.liquid + 6 + live.ramUsed / BUILD.ram.capacity * 8;
	const glow = settings.zones.ram.on ? LIGHTS[settings.zones.ram.color] : "var(--color-muted)";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					className: "p-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "In use",
						value: live.ramUsed.toFixed(1),
						unit: "GB"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					className: "p-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Available",
						value: (BUILD.ram.capacity - live.ramUsed).toFixed(1),
						unit: "GB"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					className: "p-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "DIMM",
						value: dimmTemp.toFixed(1),
						unit: "°C",
						tone: toneText(dimmTemp)
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "p-4 sm:p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: "Kit" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 text-lg font-semibold text-fg",
							children: BUILD.ram.kit
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								BUILD.ram.speed,
								" · ",
								BUILD.ram.timings,
								" · EXPO · dual channel"
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-sm tabular-nums text-muted",
						children: [
							Math.round(pct),
							"% of ",
							BUILD.ram.capacity,
							" GB"
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
						value: pct,
						label: "Memory used"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 grid gap-4 sm:grid-cols-2",
					children: [0, 1].map((slot) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-control border border-line bg-bg p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-3 flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-fg",
									children: [
										"DIMM ",
										String.fromCharCode(65 + slot),
										"2"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-xs text-muted",
									children: "32 GB"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative h-24 overflow-hidden rounded-md border border-line bg-surface",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-0 left-8 h-3 w-10 bg-bg" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex h-full items-center gap-2 px-4",
									children: Array.from({ length: 8 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "h-12 flex-1 rounded-sm border",
										style: {
											borderColor: glow,
											background: `color-mix(in oklab, ${glow} ${18 + i % 3 * 8}%, var(--color-bg))`,
											boxShadow: settings.zones.ram.on ? `0 0 12px color-mix(in oklab, ${glow} 45%, transparent)` : void 0
										}
									}, i))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-xs text-muted",
								children: [
									"Slot ",
									slot === 0 ? "A2" : "B2",
									" · populated"
								]
							})
						]
					}, slot))
				})
			]
		})]
	});
}
function Ring({ label, percent, stroke }) {
	const r = 34;
	const c = 2 * Math.PI * r;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative size-24 shrink-0 sm:size-28",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 100 100",
			className: "size-full -rotate-90",
			role: "img",
			"aria-label": label,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "50",
					cy: "50",
					r: "46",
					fill: "none",
					stroke: "color-mix(in oklab, var(--color-cyan) 35%, transparent)",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "50",
					cy: "50",
					r,
					fill: "none",
					stroke: "color-mix(in oklab, var(--color-cyan) 18%, transparent)",
					strokeWidth: "9"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "50",
					cy: "50",
					r,
					fill: "none",
					stroke,
					strokeWidth: "9",
					strokeLinecap: "round",
					strokeDasharray: `${Math.max(0, Math.min(1, percent)) * c} ${c}`,
					style: { filter: `drop-shadow(0 0 6px ${stroke})` }
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "absolute inset-0 grid place-items-center font-mono text-sm font-medium tabular-nums text-fg sm:text-base",
			children: label
		})]
	});
}
function Spark({ values, stroke }) {
	if (values.length < 2) return null;
	const min = Math.min(...values);
	const span = Math.max(...values) - min || 1;
	const d = values.map((value, i) => {
		const x = i / (values.length - 1) * 100;
		const y = 30 - (value - min) / span * 24;
		return `${i === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
	}).join(" ");
	const end = values.length - 1;
	const ex = 100;
	const ey = 30 - (values[end] - min) / span * 24;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 100 36",
		className: "h-9 w-28 sm:w-36",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d,
			fill: "none",
			stroke,
			strokeWidth: "1.8",
			vectorEffect: "non-scaling-stroke"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: ex,
			cy: ey,
			r: "2.2",
			fill: stroke
		})]
	});
}
function Toggle({ on, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": on,
		"aria-label": label,
		onClick,
		className: `press relative h-8 w-14 shrink-0 rounded-full border ${on ? "border-violet bg-violet" : "border-line bg-bg"}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-1 left-0 size-5 rounded-full transition-transform duration-150 ${on ? "translate-x-7 bg-fg" : "translate-x-1 bg-muted"}` })
	});
}
function CoolerMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 120 78",
		className: "h-16 w-28 shrink-0",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "8",
				y: "10",
				width: "104",
				height: "58",
				rx: "10",
				fill: "color-mix(in oklab, white 16%, transparent)",
				stroke: "var(--color-fg)",
				strokeOpacity: "0.7"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "39",
				r: "18",
				fill: "none",
				stroke: "var(--color-fg)",
				strokeOpacity: "0.85"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "39",
				r: "5",
				fill: "var(--color-fg)"
			}),
			[
				0,
				60,
				120,
				180,
				240,
				300
			].map((deg) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "60",
				y1: "39",
				x2: "60",
				y2: "24",
				stroke: "var(--color-fg)",
				strokeWidth: "2",
				transform: `rotate(${deg} 60 39)`
			}, deg))
		]
	});
}
var RPM = [
	{
		id: "low",
		label: "AI Low Mode"
	},
	{
		id: "med",
		label: "AI Medium Mode"
	},
	{
		id: "high",
		label: "AI High Mode"
	},
	{
		id: "custom",
		label: "Custom"
	},
	{
		id: "manual",
		label: "Manual Mode"
	}
];
function Overview() {
	const { live, settings, snap, setPowered, setRpm, setManualDuty, setHoldBand, setRgbOn, setEffect, setLightSpeed, setBrightness } = useRig();
	const history = live.history.slice(-28);
	const ccd = (id) => {
		const cores = snap.cores.filter((core) => core.ccd === id);
		const avg = cores.reduce((sum, core) => sum + core.clock, 0) / cores.length;
		return Math.round(avg * 1e3);
	};
	const mode = settings.manual ? "manual" : settings.preset === "silent" ? "low" : settings.preset === "balanced" ? "med" : settings.preset === "performance" ? "high" : "custom";
	const ramPct = live.ramUsed / BUILD.ram.capacity * 100;
	const vramPct = live.vram / BUILD.gpu.vram * 100;
	const speedShown = Math.round((settings.lightSpeed - .5) / 1.5 * 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "device-banner flex flex-wrap items-center gap-4 px-4 py-4 sm:px-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl font-semibold tracking-tight",
								children: "ZXC"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								on: settings.powered,
								label: settings.powered ? "Cooler on" : "Cooler off",
								onClick: () => setPowered(!settings.powered)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium tracking-wide",
								children: settings.powered ? "ON" : "OFF"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm opacity-80",
						children: "Link active"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-3 grid max-w-md grid-cols-3 gap-3 font-mono text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "opacity-70",
								children: "SN Code"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 text-sm text-fg",
								children: "ZX4G36019"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "opacity-70",
								children: "PID"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 text-sm text-fg",
								children: "C360"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "opacity-70",
								children: "VID"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 text-sm text-fg",
								children: "5A21"
							})] })
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ml-auto flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-semibold",
						children: "Glacier 360"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm opacity-80",
						children: "Desktop cooler"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoolerMark, {})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid items-start gap-4 xl:grid-cols-[minmax(0,1.45fr)_minmax(18rem,0.8fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-end justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: "Hardware Status"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs text-muted",
							children: "≤47° blue · 48–78° yellow · ≥79° red"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SensorRow, {
						title: "CPU",
						load: live.cpuLoad,
						temp: live.cpuTemp,
						freqLabel: "Frequency",
						freq: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"CCD0 ",
							ccd(0),
							" MHZ"
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"CCD1 ",
							ccd(1),
							" MHZ"
						] })] }),
						power: live.cpuPower,
						tempSeries: history.map((sample) => sample.cpu),
						powerSeries: history.map((sample) => sample.cpuW)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SensorRow, {
						title: "GPU",
						load: live.gpuLoad,
						temp: live.gpuTemp,
						freqLabel: "Frequency",
						freq: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [Math.round(snap.gpuClock), " MHZ"] }),
						power: live.gpuPower,
						tempSeries: history.map((sample) => sample.gpu),
						powerSeries: history.map((sample) => sample.gpuW)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlantMeter, {
							label: "DRAM",
							pct: ramPct,
							detail: `${Math.round(ramPct)}%  ${live.ramUsed.toFixed(0)} / ${BUILD.ram.capacity} GB`
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlantMeter, {
							label: "VRAM",
							pct: vramPct,
							detail: `${Math.round(vramPct)}%  ${live.vram.toFixed(0)} / ${BUILD.gpu.vram} GB`
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "panel p-4 sm:p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: "RPM Mode"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 grid grid-cols-3 gap-2",
							children: RPM.map((item) => {
								const on = mode === item.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-pressed": on,
									onClick: () => setRpm(item.id),
									className: `press flex min-h-20 flex-col items-center justify-center gap-2 rounded-control border px-2 py-3 text-center text-xs ${on ? "rpm-on" : "border-line text-muted"}`,
									children: [item.id === "custom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Grid2x2, {
										className: "size-6",
										strokeWidth: 1.75
									}) : item.id === "manual" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, {
										className: "size-6",
										strokeWidth: 1.75
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fan, {
										className: "size-6",
										strokeWidth: 1.75
									}), item.label]
								}, item.id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 font-mono text-sm text-fg",
							children: [
								"Current Speed: ",
								Math.round(live.fanDuty),
								"%"
							]
						}),
						mode === "manual" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-2 block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted",
								children: "Manual duty"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "duty",
								type: "range",
								min: 0,
								max: 100,
								value: Math.round(settings.manualDuty),
								"aria-label": "Manual fan duty",
								onChange: (e) => setManualDuty(Number(e.target.value))
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-3 flex items-start gap-2 text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "mt-1 size-4 accent-violet",
								checked: settings.holdBand,
								onChange: (e) => setHoldBand(e.target.checked)
							}), "Speed does not change when temperature is ±3°C"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "panel p-4 sm:p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg font-semibold",
								children: "RGB Lighting Control"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								on: settings.rgbOn && settings.powered,
								label: "RGB lighting",
								onClick: () => setRgbOn(!settings.rgbOn)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-4 block text-sm text-muted",
							children: ["Mode", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: settings.effect,
								onChange: (e) => setEffect(e.target.value),
								className: "mt-2 h-11 w-full rounded-control border border-line bg-bg px-3 text-base text-fg",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "solid",
										children: "Solid"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "breathe",
										children: "Breathe"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "wave",
										children: "Wave"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "chase",
										children: "Color Chase"
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRow, {
							label: "Brightness",
							value: settings.brightness,
							min: 0,
							max: 100,
							onChange: setBrightness
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRow, {
							label: "Speed",
							value: speedShown,
							min: 0,
							max: 100,
							onChange: (value) => setLightSpeed(.5 + value / 100 * 1.5)
						})
					]
				})]
			})]
		})]
	});
}
function SensorRow({ title, load, temp, freqLabel, freq, power, tempSeries, powerSeries }) {
	const tempStroke = toneStroke(temp);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-5 border-t border-line pt-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-medium tracking-wide text-fg",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex flex-wrap items-center gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ring, {
					label: `${Math.round(load * 100)}%`,
					percent: load,
					stroke: "var(--color-cyan)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ring, {
					label: `${Math.round(temp)}°C`,
					percent: Math.min(1, temp / 105),
					stroke: tempStroke
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid min-w-40 flex-1 gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center gap-2 text-violet",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spark, {
								values: tempSeries,
								stroke: "var(--color-violet)"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: freqLabel
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-mono text-sm tabular-nums text-fg",
							children: freq
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spark, {
							values: powerSeries,
							stroke: "var(--color-cyan)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "Thermal Power Consumption"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-sm tabular-nums text-fg",
							children: [Math.round(power), " W"]
						})
					] })]
				})
			]
		})]
	});
}
function SlantMeter({ label, pct, detail }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "w-12 text-xs font-medium tracking-wide text-fg",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "slant-track relative min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "slant-fill",
				style: { width: `${Math.max(8, Math.min(100, pct))}%` }
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "absolute inset-0 grid place-items-center font-mono text-xs tabular-nums text-fg",
				children: detail
			})]
		})]
	});
}
function SliderRow({ label, value, min, max, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "mt-3 grid grid-cols-[5.5rem_minmax(0,1fr)_3rem] items-center gap-2 text-sm text-muted",
		children: [
			label,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "duty",
				type: "range",
				min,
				max,
				value: Math.round(value),
				"aria-label": label,
				onChange: (e) => onChange(Number(e.target.value))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-control border border-line bg-bg py-2 text-center font-mono text-sm tabular-nums text-fg",
				children: Math.round(value)
			})
		]
	});
}
function StorageView() {
	const { snap } = useRig();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-col gap-4",
		children: snap.drives.map((drive) => {
			const usedGb = drive.capacityGb * drive.used;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `size-2 rounded-full ${drive.activity > .15 ? "bg-cyan" : "bg-line"}`,
										"aria-hidden": true
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eyebrow, { children: drive.kind })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 truncate text-lg font-semibold text-fg",
									children: drive.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: drive.iface
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
							label: "Drive",
							value: drive.temp.toFixed(1),
							unit: "°C",
							tone: toneText(drive.temp)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 grid gap-4 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-widest text-muted uppercase",
								children: "Read"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 font-mono text-xl tabular-nums text-fg",
								children: [Math.round(drive.read), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-1 text-xs text-muted",
									children: "MB/s"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-widest text-muted uppercase",
								children: "Write"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 font-mono text-xl tabular-nums text-fg",
								children: [Math.round(drive.write), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-1 text-xs text-muted",
									children: "MB/s"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-widest text-muted uppercase",
								children: "Activity"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 font-mono text-xl tabular-nums text-fg",
								children: [Math.round(drive.activity * 100), "%"]
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex justify-between text-xs text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [Math.round(usedGb), " GB used"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [drive.capacityGb / 1e3, " TB"] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
							value: drive.used * 100,
							label: `${drive.name} capacity`
						})]
					})
				]
			}, drive.id);
		})
	});
}
var NAV = [
	{
		id: "overview",
		label: "Overview",
		icon: Gauge
	},
	{
		id: "cooling",
		label: "Cooling",
		icon: Fan
	},
	{
		id: "cpu",
		label: "Processor",
		icon: Cpu
	},
	{
		id: "gpu",
		label: "Graphics",
		icon: Monitor
	},
	{
		id: "memory",
		label: "Memory",
		icon: MemoryStick
	},
	{
		id: "storage",
		label: "Storage",
		icon: HardDrive
	},
	{
		id: "lighting",
		label: "Lighting",
		icon: Lightbulb
	}
];
function Mark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 36 36",
		className: "size-9 shrink-0",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "0.5",
			y: "0.5",
			width: "35",
			height: "35",
			rx: "10",
			fill: "var(--color-surface)",
			stroke: "var(--color-line)"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M10 12h16L10 24h16",
			fill: "none",
			stroke: "var(--color-cyan)",
			strokeWidth: "2.2",
			strokeLinejoin: "round",
			strokeLinecap: "round"
		})]
	});
}
function Shell() {
	const { live, settings, snap, view, setView, setProfile, setRigName, setAlerts, resetTuning } = useRig();
	const [limitsOpen, setLimitsOpen] = (0, import_react.useState)(false);
	const [isFull, setIsFull] = (0, import_react.useState)(false);
	const limitsRef = (0, import_react.useRef)(null);
	const cpuHot = live.cpuTemp >= settings.cpuAlert;
	const gpuHot = live.gpuTemp >= settings.gpuAlert;
	(0, import_react.useEffect)(() => {
		const sync = () => setIsFull(document.fullscreenElement != null);
		document.addEventListener("fullscreenchange", sync);
		return () => document.removeEventListener("fullscreenchange", sync);
	}, []);
	async function toggleFull() {
		try {
			if (document.fullscreenElement) await document.exitFullscreen();
			else await document.documentElement.requestFullscreen();
		} catch {}
	}
	(0, import_react.useEffect)(() => {
		if (!limitsOpen) return;
		const onPointer = (event) => {
			if (!limitsRef.current?.contains(event.target)) setLimitsOpen(false);
		};
		document.addEventListener("pointerdown", onPointer);
		return () => document.removeEventListener("pointerdown", onPointer);
	}, [limitsOpen]);
	const page = {
		overview: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overview, {}),
		cooling: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cooling, {}),
		cpu: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CpuView, {}),
		gpu: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GpuView, {}),
		memory: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemoryView, {}),
		storage: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StorageView, {}),
		lighting: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lighting, {})
	}[view];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "relative min-h-dvh",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-dvh w-full max-w-[1440px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "sticky top-0 hidden h-dvh w-56 shrink-0 flex-col border-r border-line px-3 py-5 md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 px-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-base leading-none font-semibold tracking-wide",
							children: "ZXC"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs tracking-widest text-muted uppercase",
							children: "Cam"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-8 flex flex-col gap-1",
						"aria-label": "Sections",
						children: NAV.map((item) => {
							const on = view === item.id;
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-current": on ? "page" : void 0,
								onClick: () => setView(item.id),
								className: `press flex h-11 items-center gap-3 rounded-control border-l-2 px-3 text-left text-sm ${on ? "border-cyan bg-raised text-fg" : "border-transparent text-muted hover:bg-raised hover:text-fg"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-4",
									strokeWidth: 1.75
								}), item.label]
							}, item.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-auto px-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-widest text-muted uppercase",
								children: "Showcase link"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-mono text-xs text-muted",
								children: "12 probes · 400 ms"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-muted",
								children: "Thermal model of this rig, not the device you're on."
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "topbar sticky top-0 z-20 border-b border-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-3 px-4 py-3 md:px-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex min-w-0 items-center gap-3 md:hidden",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "sr-only",
										children: "ZXC Cam"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-xs tracking-widest text-muted uppercase",
											htmlFor: "rig-name",
											children: "Rig"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: "rig-name",
											value: settings.rigName,
											spellCheck: false,
											maxLength: 18,
											"aria-label": "Rig name",
											onChange: (e) => setRigName(e.target.value),
											onBlur: () => {
												if (!settings.rigName.trim()) setRigName("FORGE-01");
											},
											className: "w-36 bg-transparent text-base font-semibold tracking-wide text-fg outline-none"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "ml-auto flex items-center gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "hidden font-mono text-xs tabular-nums text-muted sm:block",
												children: formatUptime(snap.uptime)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-2 text-xs tracking-widest text-cyan uppercase",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "relative flex size-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "live-ping absolute inline-flex size-full rounded-full bg-cyan opacity-70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "relative size-2 rounded-full bg-cyan" })]
												}), "Live"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => void toggleFull(),
												"aria-pressed": isFull,
												className: "press flex h-11 items-center gap-2 rounded-control border border-cyan px-3 text-sm text-fg",
												children: [isFull ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minimize2, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "hidden sm:inline",
													children: isFull ? "Exit" : "Full screen"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "relative",
												ref: limitsRef,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													"aria-expanded": limitsOpen,
													"aria-label": "Thermal limits",
													onClick: () => setLimitsOpen((v) => !v),
													className: "press grid size-11 place-items-center rounded-control border border-line text-muted hover:text-fg",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-4" })
												}), limitsOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "panel absolute right-0 z-30 mt-2 w-72 p-4",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-sm font-medium text-fg",
															children: "Thermal limits"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "mt-1 text-xs text-muted",
															children: "Alerts fire when a package crosses the line."
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
															className: "mt-3 flex items-center justify-between gap-3 text-sm text-muted",
															children: ["CPU", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
																type: "number",
																min: 70,
																max: 105,
																value: Math.round(settings.cpuAlert),
																onChange: (e) => {
																	const n = Number(e.target.value);
																	if (Number.isFinite(n)) setAlerts(n, settings.gpuAlert);
																},
																onBlur: (e) => setAlerts(clamp(Number(e.target.value) || 90, 70, 105), settings.gpuAlert),
																className: "h-11 w-20 rounded-control border border-line bg-bg px-2 text-center font-mono text-base text-fg"
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
															className: "mt-2 flex items-center justify-between gap-3 text-sm text-muted",
															children: ["GPU", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
																type: "number",
																min: 70,
																max: 105,
																value: Math.round(settings.gpuAlert),
																onChange: (e) => {
																	const n = Number(e.target.value);
																	if (Number.isFinite(n)) setAlerts(settings.cpuAlert, n);
																},
																onBlur: (e) => setAlerts(settings.cpuAlert, clamp(Number(e.target.value) || 85, 70, 105)),
																className: "h-11 w-20 rounded-control border border-line bg-bg px-2 text-center font-mono text-base text-fg"
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => {
																resetTuning();
																setLimitsOpen(false);
															},
															className: "press mt-3 h-11 w-full rounded-control border border-line text-sm text-muted hover:text-fg",
															children: "Reset curve and lighting"
														})
													]
												}) : null]
											})
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-2 overflow-x-auto px-4 pb-3 md:px-6",
								role: "group",
								"aria-label": "Workload",
								children: PROFILES.map((profile) => {
									const on = settings.profile === profile.id;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-pressed": on,
										onClick: () => setProfile(profile.id),
										className: `press h-11 shrink-0 rounded-control px-4 text-sm font-medium ${on ? "bg-cyan text-fg" : "bg-raised text-muted hover:text-fg"}`,
										children: profile.label
									}, profile.id);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
								className: "flex gap-1 overflow-x-auto border-t border-line px-3 py-2 md:hidden",
								"aria-label": "Sections",
								children: NAV.map((item) => {
									const on = view === item.id;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-current": on ? "page" : void 0,
										onClick: () => setView(item.id),
										className: `press h-11 shrink-0 rounded-control px-3 text-sm ${on ? "bg-raised text-fg" : "text-muted"}`,
										children: item.label
									}, item.id);
								})
							})
						]
					}),
					cpuHot || gpuHot ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "alert-bar px-4 py-3 text-sm md:px-6",
						role: "status",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							cpuHot ? `CPU package ${live.cpuTemp.toFixed(0)}° is past ${Math.round(settings.cpuAlert)}°. ` : "",
							gpuHot ? `GPU edge ${live.gpuTemp.toFixed(0)}° is past ${Math.round(settings.gpuAlert)}°. ` : "",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "underline",
								onClick: () => setView("cooling"),
								children: "Open cooling"
							})
						] })
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
						className: "min-w-0 flex-1 px-4 py-5 md:px-6 md:py-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "view-enter",
							children: page
						}, view), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-6 text-xs text-muted",
							children: [
								settings.rigName || "FORGE-01",
								" · ",
								BUILD.cpu.name,
								" · ",
								BUILD.gpu.name
							]
						})]
					})
				]
			})]
		})
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RigProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {}) });
}
//#endregion
export { useRig as n, routes_exports as t };
