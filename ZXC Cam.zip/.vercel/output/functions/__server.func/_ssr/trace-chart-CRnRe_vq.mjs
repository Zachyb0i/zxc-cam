import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useRig } from "./routes-DQ5ZnVj0.mjs";
import { a as Tooltip, i as CartesianGrid, n as YAxis, r as Area, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/trace-chart-CRnRe_vq.js
var import_jsx_runtime = require_jsx_runtime();
function Tip({ active, payload, unit }) {
	if (!active || !payload?.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-control border border-line bg-raised px-3 py-2 font-mono text-xs text-fg",
		children: payload.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "tabular-nums",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					style: { color: item.color },
					children: item.dataKey === "a" ? "CPU" : "GPU"
				}),
				"  ",
				typeof item.value === "number" ? item.value.toFixed(item.value > 120 ? 0 : 1) : "–",
				unit
			]
		}, String(item.dataKey)))
	});
}
function TraceChart({ width, height, mode, series }) {
	const { live } = useRig();
	const data = live.history.map((sample, i) => ({
		i,
		a: mode === "temp" ? sample.cpu : sample.cpuW,
		b: mode === "temp" ? sample.gpu : sample.gpuW
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
		width,
		height,
		data,
		margin: {
			top: 8,
			right: 8,
			left: 0,
			bottom: 0
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
				vertical: false,
				stroke: "var(--color-line)",
				strokeDasharray: "3 8"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
				domain: mode === "temp" ? [25, 100] : [0, 640],
				width: 40,
				tick: {
					fill: "var(--color-muted)",
					fontSize: 11,
					fontFamily: "IBM Plex Mono, monospace"
				},
				axisLine: false,
				tickLine: false,
				tickCount: 5
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, { unit: mode === "temp" ? "°" : "W" }) }),
			series !== "gpu" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
				type: "monotone",
				dataKey: "a",
				stroke: "var(--color-cyan)",
				fill: "var(--color-cyan)",
				fillOpacity: .16,
				strokeWidth: 2,
				isAnimationActive: false,
				dot: false
			}) : null,
			series !== "cpu" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
				type: "monotone",
				dataKey: "b",
				stroke: "var(--color-hot)",
				fill: "var(--color-hot)",
				fillOpacity: .12,
				strokeWidth: 2,
				isAnimationActive: false,
				dot: false
			}) : null
		]
	});
}
//#endregion
export { TraceChart };
