#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static const char MAGIC[8] = {'Z', 'X', 'C', 'A', 'M', 'P', 'K', '1'};

static void die(const wchar_t *msg) {
    MessageBoxW(NULL, msg, L"ZXC Cam Setup", MB_ICONERROR | MB_OK);
    ExitProcess(1);
}

static int run_hidden(wchar_t *cmdline) {
    STARTUPINFOW si;
    PROCESS_INFORMATION pi;
    DWORD code = 1;
    ZeroMemory(&si, sizeof(si));
    ZeroMemory(&pi, sizeof(pi));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    if (!CreateProcessW(NULL, cmdline, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) return 0;
    WaitForSingleObject(pi.hProcess, 180000);
    GetExitCodeProcess(pi.hProcess, &code);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
    return code == 0;
}

int WINAPI WinMain(HINSTANCE instance, HINSTANCE prev, LPSTR command, int show) {
    wchar_t self[1024];
    wchar_t temp_dir[1024];
    wchar_t zip_path[1024];
    wchar_t script_path[1024];
    wchar_t local_app[1024];
    wchar_t dest[1024];
    wchar_t exe_path[1024];
    wchar_t cmdline[4096];
    unsigned char tail[16];
    unsigned char buf[65536];
    LARGE_INTEGER size;
    LARGE_INTEGER pos;
    uint64_t zip_len = 0;
    uint64_t left;
    DWORD got = 0;
    HANDLE file;
    HANDLE zip;
    HANDLE script;
    HINSTANCE launched;
    (void)instance;
    (void)prev;
    (void)command;
    (void)show;

    if (!GetModuleFileNameW(NULL, self, 1024)) die(L"Could not find the setup file.");
    file = CreateFileW(self, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (file == INVALID_HANDLE_VALUE) die(L"Could not read the setup file.");
    if (!GetFileSizeEx(file, &size) || size.QuadPart < 32) die(L"Setup file is incomplete.");

    pos.QuadPart = size.QuadPart - 16;
    if (!SetFilePointerEx(file, pos, NULL, FILE_BEGIN) || !ReadFile(file, tail, 16, &got, NULL) || got != 16) {
        die(L"Setup file is incomplete.");
    }
    if (memcmp(tail + 8, MAGIC, 8) != 0) die(L"Setup file is incomplete.");
    memcpy(&zip_len, tail, 8);
    if (zip_len < 32 || (LONGLONG)zip_len > size.QuadPart - 16) die(L"Setup file is incomplete.");

    if (!GetTempPathW(1024, temp_dir)) die(L"Could not use the temp folder.");
    if (swprintf(zip_path, 1024, L"%lsZXCCam-payload.zip", temp_dir) < 0) die(L"Could not prepare the install.");
    if (swprintf(script_path, 1024, L"%lsZXCCam-install.ps1", temp_dir) < 0) die(L"Could not prepare the install.");

    zip = CreateFileW(zip_path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (zip == INVALID_HANDLE_VALUE) die(L"Could not write the install package.");
    pos.QuadPart = size.QuadPart - 16 - (LONGLONG)zip_len;
    if (!SetFilePointerEx(file, pos, NULL, FILE_BEGIN)) die(L"Could not read the install package.");
    left = zip_len;
    while (left) {
        DWORD chunk = left > sizeof(buf) ? (DWORD)sizeof(buf) : (DWORD)left;
        DWORD wrote = 0;
        if (!ReadFile(file, buf, chunk, &got, NULL) || got == 0) die(L"Could not read the install package.");
        if (!WriteFile(zip, buf, got, &wrote, NULL) || wrote != got) die(L"Could not write the install package.");
        left -= got;
    }
    CloseHandle(zip);
    CloseHandle(file);

    if (!GetEnvironmentVariableW(L"LOCALAPPDATA", local_app, 1024)) die(L"Could not find your user folder.");
    if (swprintf(dest, 1024, L"%ls\\ZXC Cam", local_app) < 0) die(L"Could not choose an install folder.");
    CreateDirectoryW(dest, NULL);

    {
        static const wchar_t body[] =
            L"param([Parameter(Mandatory=$true)][string]$Zip,[Parameter(Mandatory=$true)][string]$Dest)\r\n"
            L"$ErrorActionPreference = 'Stop'\r\n"
            L"New-Item -ItemType Directory -Force -Path $Dest | Out-Null\r\n"
            L"Expand-Archive -LiteralPath $Zip -DestinationPath $Dest -Force\r\n"
            L"$exe = Join-Path $Dest 'ZXC Cam.exe'\r\n"
            L"if (-not (Test-Path -LiteralPath $exe)) { throw 'missing app' }\r\n"
            L"$shell = New-Object -ComObject WScript.Shell\r\n"
            L"$programs = Join-Path $env:APPDATA 'Microsoft\\Windows\\Start Menu\\Programs'\r\n"
            L"$link = $shell.CreateShortcut((Join-Path $programs 'ZXC Cam.lnk'))\r\n"
            L"$link.TargetPath = $exe\r\n"
            L"$link.WorkingDirectory = $Dest\r\n"
            L"$link.Description = 'ZXC Cam'\r\n"
            L"$link.Save()\r\n"
            L"$desk = [Environment]::GetFolderPath('Desktop')\r\n"
            L"if ($desk) {\r\n"
            L"  $dlink = $shell.CreateShortcut((Join-Path $desk 'ZXC Cam.lnk'))\r\n"
            L"  $dlink.TargetPath = $exe\r\n"
            L"  $dlink.WorkingDirectory = $Dest\r\n"
            L"  $dlink.Description = 'ZXC Cam'\r\n"
            L"  $dlink.Save()\r\n"
            L"}\r\n"
            L"$un = $shell.CreateShortcut((Join-Path $programs 'Uninstall ZXC Cam.lnk'))\r\n"
            L"$un.TargetPath = Join-Path $env:SystemRoot 'System32\\wscript.exe'\r\n"
            L"$un.Arguments = '/nologo \"' + (Join-Path $Dest 'uninstall.vbs') + '\"'\r\n"
            L"$un.WorkingDirectory = $Dest\r\n"
            L"$un.Save()\r\n";
        unsigned char bom[2] = {0xFF, 0xFE};
        DWORD wrote = 0;
        script = CreateFileW(script_path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        if (script == INVALID_HANDLE_VALUE) die(L"Could not prepare the install.");
        if (!WriteFile(script, bom, 2, &wrote, NULL) ||
            !WriteFile(script, body, (DWORD)((sizeof(body) / sizeof(wchar_t) - 1) * sizeof(wchar_t)), &wrote, NULL)) {
            die(L"Could not prepare the install.");
        }
        CloseHandle(script);
    }

    if (swprintf(cmdline, 4096,
                 L"powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"%ls\" -Zip \"%ls\" -Dest \"%ls\"",
                 script_path, zip_path, dest) < 0) {
        die(L"Could not start the install.");
    }
    if (!run_hidden(cmdline)) die(L"Install did not finish. ZXC Cam was not copied.");

    DeleteFileW(zip_path);
    DeleteFileW(script_path);

    if (swprintf(exe_path, 1024, L"%ls\\ZXC Cam.exe", dest) < 0) die(L"ZXC Cam was installed, but it could not be opened.");
    launched = ShellExecuteW(NULL, L"open", exe_path, NULL, dest, SW_SHOWNORMAL);
    if ((INT_PTR)launched <= 32) die(L"ZXC Cam is installed, but it could not be opened.");
    return 0;
}
