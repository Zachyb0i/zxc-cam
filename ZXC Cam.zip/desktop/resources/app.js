const BLUE = "#3d7dff";
const history = { cpu: [], gpu: [] };
let full = false;

function tone(temp) {
  if (temp == null || Number.isNaN(temp)) return "#35507a";
  if (temp <= 47) return BLUE;
  if (temp <= 78) return "#f5c518";
  return "#ff3348";
}

function ring(id, label, percent, stroke) {
  const host = document.getElementById(id);
  const pct = Math.max(0, Math.min(1, percent || 0));
  const r = 34;
  const c = 2 * Math.PI * r;
  host.setAttribute("aria-label", label);
  host.innerHTML =
    '<svg viewBox="0 0 100 100" aria-hidden="true">' +
    '<circle cx="50" cy="50" r="46" fill="none" stroke="rgba(61,125,255,0.35)" stroke-width="2"></circle>' +
    '<circle cx="50" cy="50" r="34" fill="none" stroke="rgba(61,125,255,0.18)" stroke-width="9"></circle>' +
    '<circle cx="50" cy="50" r="34" fill="none" stroke="' + stroke + '" stroke-width="9" stroke-linecap="round" stroke-dasharray="' + (pct * c).toFixed(2) + ' ' + c.toFixed(2) + '"></circle>' +
    "</svg><span>" + label + "</span>";
}

function spark(id, values, stroke) {
  const svg = document.getElementById(id);
  if (!values || values.length < 2) {
    svg.innerHTML = "";
    return;
  }
  const min = Math.min.apply(null, values);
  const max = Math.max.apply(null, values);
  const span = max - min || 1;
  let d = "";
  values.forEach(function (value, i) {
    const x = (i / (values.length - 1)) * 100;
    const y = 30 - ((value - min) / span) * 24;
    d += (i === 0 ? "M" : "L") + x.toFixed(1) + " " + y.toFixed(1) + " ";
  });
  svg.innerHTML = '<path d="' + d + '" fill="none" stroke="' + stroke + '" stroke-width="1.8"></path>';
}

function text(id, value) {
  document.getElementById(id).textContent = value;
}

function push(list, value) {
  if (value == null || Number.isNaN(value)) return;
  list.push(value);
  if (list.length > 28) list.shift();
}

function show(sample) {
  const cpu = sample.cpu || {};
  const gpu = sample.gpu || {};
  const ram = sample.ram || {};
  text("status", cpu.temp == null && gpu.temp == null ? "Live · no temperature sensor yet" : "Live");
  text("cpu-name", cpu.name || "CPU");
  text("gpu-name", gpu.name || "GPU");
  ring("cpu-load-ring", cpu.load == null ? "—" : Math.round(cpu.load) + "%", (cpu.load || 0) / 100, BLUE);
  ring(
    "cpu-temp-ring",
    cpu.temp == null ? "—" : Math.round(cpu.temp) + "°C",
    cpu.temp == null ? 0 : Math.min(1, cpu.temp / 105),
    tone(cpu.temp),
  );
  ring("gpu-load-ring", gpu.load == null ? "—" : Math.round(gpu.load) + "%", (gpu.load || 0) / 100, BLUE);
  ring(
    "gpu-temp-ring",
    gpu.temp == null ? "—" : Math.round(gpu.temp) + "°C",
    gpu.temp == null ? 0 : Math.min(1, gpu.temp / 105),
    tone(gpu.temp),
  );
  text("cpu-mhz", cpu.mhz ? cpu.mhz + " MHZ" : "—");
  text("cpu-power", cpu.power == null ? "Not reported" : Math.round(cpu.power) + " W");
  text("cpu-source", cpu.source === "acpi" ? "ACPI zone" : cpu.source === "package" ? "Package" : "");
  text("gpu-mhz", gpu.mhz ? gpu.mhz + " MHZ" : "—");
  text("gpu-power", gpu.power == null ? "Not reported" : Math.round(gpu.power) + " W");
  text("gpu-fan", gpu.fan == null ? "" : "Fan " + Math.round(gpu.fan) + "%");
  push(history.cpu, cpu.temp);
  push(history.gpu, gpu.temp);
  spark("cpu-spark", history.cpu, tone(cpu.temp));
  spark("gpu-spark", history.gpu, tone(gpu.temp));
  const ramPct = ram.used != null && ram.total ? Math.max(0, Math.min(100, (ram.used / ram.total) * 100)) : 0;
  document.getElementById("ram-fill").style.width = Math.max(ramPct, ramPct ? 8 : 0) + "%";
  text("ram-label", ram.used == null ? "—" : Math.round(ramPct) + "%  " + ram.used.toFixed(0) + " / " + ram.total.toFixed(0) + " GB");
  const vramPct = gpu.vramUsed != null && gpu.vramTotal ? Math.max(0, Math.min(100, (gpu.vramUsed / gpu.vramTotal) * 100)) : 0;
  document.getElementById("vram-fill").style.width = Math.max(vramPct, vramPct ? 8 : 0) + "%";
  text(
    "vram-label",
    gpu.vramUsed == null ? "—" : Math.round(vramPct) + "%  " + gpu.vramUsed.toFixed(1) + " / " + gpu.vramTotal.toFixed(0) + " GB",
  );
}

async function readSample() {
  const base = String(NL_PATH).replace(/\\/g, "/").replace(/\/$/, "");
  const raw = await Neutralino.filesystem.readFile(base + "/resources/live.json");
  return JSON.parse(raw);
}

async function tick() {
  try {
    show(await readSample());
  } catch (error) {
    text("status", "Waiting for sensors");
  }
}

async function stopSensor() {
  try {
    await Neutralino.os.execCommand('wscript.exe //nologo "' + NL_PATH + '/stop-sensors.vbs"');
  } catch (error) {
    /* the window is closing */
  }
}

async function boot() {
  await Neutralino.init();
  await Neutralino.events.on("windowClose", async function () {
    await stopSensor();
    await Neutralino.app.exit();
  });
  await Neutralino.os.execCommand('wscript.exe //nologo "' + NL_PATH + '/start-sensors.vbs"');
  document.getElementById("full").addEventListener("click", async function () {
    full = !full;
    if (full) await Neutralino.window.setFullScreen();
    else await Neutralino.window.exitFullScreen();
    const button = document.getElementById("full");
    button.setAttribute("aria-pressed", full ? "true" : "false");
    button.textContent = full ? "Exit" : "Full screen";
  });
  await tick();
  setInterval(tick, 1000);
}

boot().catch(function () {
  text("status", "Sensor link failed");
});
