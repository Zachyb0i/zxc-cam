param(
  [Parameter(Mandatory = $true)][string]$OutFile
)

$ErrorActionPreference = "SilentlyContinue"
$dir = Split-Path -Parent $OutFile
if ($dir -and -not (Test-Path $dir)) {
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
}
[System.IO.File]::WriteAllText((Join-Path $dir "sensor.pid"), "$PID")

function Round1($n) {
  if ($null -eq $n) { return $null }
  return [math]::Round([double]$n, 1)
}

function Num($text) {
  if ([string]::IsNullOrWhiteSpace($text)) { return $null }
  $clean = $text.Trim()
  if ($clean -eq "[N/A]" -or $clean -eq "N/A") { return $null }
  try {
    return [double]::Parse($clean, [System.Globalization.CultureInfo]::InvariantCulture)
  } catch {
    return $null
  }
}

$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
$cpuName = [string]$cpu.Name
$baseMhz = [double]$cpu.MaxClockSpeed
$osInfo = Get-CimInstance Win32_OperatingSystem
$ramTotal = [math]::Round($osInfo.TotalVisibleMemorySize / 1MB, 1)

$nvidia = $null
foreach ($candidate in @(
  "nvidia-smi",
  "$env:ProgramFiles\NVIDIA Corporation\NVSMI\nvidia-smi.exe",
  "${env:ProgramFiles(x86)}\NVIDIA Corporation\NVSMI\nvidia-smi.exe"
)) {
  if ($candidate -eq "nvidia-smi") {
    $cmd = Get-Command nvidia-smi -ErrorAction SilentlyContinue
    if ($cmd) { $nvidia = $cmd.Source; break }
  } elseif (Test-Path $candidate) {
    $nvidia = $candidate
    break
  }
}

$gpuName = $null
$video = Get-CimInstance Win32_VideoController | Where-Object { $_.Name -and $_.Name -notmatch "Microsoft Basic" } | Select-Object -First 1
if ($video) { $gpuName = [string]$video.Name }

while ($true) {
  $load = $null
  $procs = Get-CimInstance Win32_Processor
  if ($procs) {
    $load = Round1(($procs | Measure-Object -Property LoadPercentage -Average).Average)
  }

  $mhz = $null
  $sample = Get-Counter "\Processor Information(_Total)\% Processor Performance" -ErrorAction SilentlyContinue
  if ($sample -and $baseMhz -gt 0) {
    $ratio = [double]$sample.CounterSamples[0].CookedValue
    if ($ratio -gt 0) { $mhz = [math]::Round($baseMhz * $ratio / 100) }
  }
  if (-not $mhz -and $cpu.CurrentClockSpeed) { $mhz = [int]$cpu.CurrentClockSpeed }

  $cpuTemp = $null
  $cpuSource = $null
  $cpuPower = $null
  $lhm = Get-CimInstance -Namespace "root/LibreHardwareMonitor" -ClassName Sensor
  if (-not $lhm) {
    $lhm = Get-CimInstance -Namespace "root/OpenHardwareMonitor" -ClassName Sensor
  }
  if ($lhm) {
    $temps = @($lhm | Where-Object { $_.SensorType -eq "Temperature" -and $_.Value -gt 5 -and $_.Value -lt 125 })
    $pkg = $temps | Where-Object { $_.Name -match "Package|Tctl|Tdie|CCD1" } | Select-Object -First 1
    if (-not $pkg) { $pkg = $temps | Where-Object { $_.Parent -match "cpu" -or $_.Name -match "Core" } | Select-Object -First 1 }
    if ($pkg) {
      $cpuTemp = Round1 $pkg.Value
      $cpuSource = "package"
    }
    $power = $lhm | Where-Object { $_.SensorType -eq "Power" -and $_.Name -match "Package|CPU" } | Select-Object -First 1
    if ($power) { $cpuPower = Round1 $power.Value }
  }
  if (-not $cpuTemp) {
    $zones = @(Get-CimInstance -Namespace "root/wmi" -ClassName MSAcpi_ThermalZoneTemperature)
    $best = $null
    foreach ($zone in $zones) {
      $c = [double]$zone.CurrentTemperature / 10.0 - 273.15
      if ($c -gt 5 -and $c -lt 125 -and (($null -eq $best) -or $c -gt $best)) { $best = $c }
    }
    if ($null -ne $best) {
      $cpuTemp = Round1 $best
      $cpuSource = "acpi"
    }
  }

  $gpuTemp = $null
  $gpuLoad = $null
  $gpuPower = $null
  $gpuMhz = $null
  $vramUsed = $null
  $vramTotal = $null
  $gpuFan = $null
  if ($nvidia) {
    $stats = & $nvidia --query-gpu=temperature.gpu,utilization.gpu,power.draw,clocks.sm,memory.used,memory.total,fan.speed --format=csv,noheader,nounits
    $nameLine = & $nvidia --query-gpu=name --format=csv,noheader
    if ($nameLine) { $gpuName = ($nameLine | Select-Object -First 1).Trim() }
    $line = $null
    if ($stats -is [array]) { $line = $stats[0] } else { $line = $stats }
    if ($line) {
      $parts = $line.Split(",")
      if ($parts.Length -ge 7) {
        $gpuTemp = Round1 (Num $parts[0])
        $gpuLoad = Round1 (Num $parts[1])
        $gpuPower = Round1 (Num $parts[2])
        $gpuMhz = Num $parts[3]
        if ($null -ne $gpuMhz) { $gpuMhz = [math]::Round($gpuMhz) }
        $vramUsed = Round1 ((Num $parts[4]) / 1024)
        $vramTotal = Round1 ((Num $parts[5]) / 1024)
        $gpuFan = Round1 (Num $parts[6])
      }
    }
  }

  $ramUsed = $null
  $osNow = Get-CimInstance Win32_OperatingSystem
  if ($osNow) {
    $free = [double]$osNow.FreePhysicalMemory / 1MB
    $ramUsed = [math]::Round($ramTotal - $free, 1)
  }

  $payload = [ordered]@{
    ok = $true
    cpu = [ordered]@{
      name = $cpuName
      temp = $cpuTemp
      source = $cpuSource
      load = $load
      mhz = $mhz
      power = $cpuPower
    }
    gpu = [ordered]@{
      name = $gpuName
      temp = $gpuTemp
      load = $gpuLoad
      mhz = $gpuMhz
      power = $gpuPower
      fan = $gpuFan
      vramUsed = $vramUsed
      vramTotal = $vramTotal
    }
    ram = [ordered]@{
      used = $ramUsed
      total = $ramTotal
    }
    at = (Get-Date).ToUniversalTime().ToString("o")
  }
  $json = $payload | ConvertTo-Json -Compress -Depth 6
  $tmp = "$OutFile.tmp"
  [System.IO.File]::WriteAllText($tmp, $json)
  Move-Item -Force $tmp $OutFile
  Start-Sleep -Milliseconds 800
}
