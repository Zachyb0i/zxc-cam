Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
pidFile = dir & "\resources\sensor.pid"
If Not fso.FileExists(pidFile) Then WScript.Quit 0
pid = Trim(fso.OpenTextFile(pidFile).ReadAll)
If pid = "" Then WScript.Quit 0
CreateObject("Wscript.Shell").Run "taskkill /PID " & pid & " /T /F", 0, True
