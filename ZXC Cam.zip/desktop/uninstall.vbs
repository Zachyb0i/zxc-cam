Set shell = CreateObject("Wscript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
On Error Resume Next
fso.DeleteFile shell.SpecialFolders("Desktop") & "\ZXC Cam.lnk", True
fso.DeleteFile shell.SpecialFolders("Programs") & "\ZXC Cam.lnk", True
fso.DeleteFile shell.SpecialFolders("Programs") & "\Uninstall ZXC Cam.lnk", True
dir = fso.GetParentFolderName(WScript.ScriptFullName)
shell.Run "cmd.exe /c ping -n 2 127.0.0.1 >nul & rmdir /s /q """ & dir & """", 0, False
