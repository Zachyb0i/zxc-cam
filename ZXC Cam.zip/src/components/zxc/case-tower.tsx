import type { CSSProperties } from "react";
import { FanGlyph } from "@/components/zxc/fans";
import { LIGHTS, type Effect, type Settings, type Snap } from "@/lib/rig";

function glowStyle(
  on: boolean,
  color: string,
  effect: Effect,
  speed: number,
  delay: string,
  lit: boolean,
  brightness: number,
): CSSProperties {
  if (!on || !lit) return { color: "var(--color-muted)" };
  const amount = Math.max(12, Math.round(brightness * 0.55));
  return {
    color,
    borderColor: color,
    boxShadow: `0 0 22px color-mix(in oklab, ${color} ${amount}%, transparent)`,
    animationDuration: effect === "solid" ? undefined : `${(2.8 / (effect === "chase" ? speed * 1.6 : speed)).toFixed(2)}s`,
    animationDelay: effect === "wave" || effect === "chase" ? delay : undefined,
  };
}

export function CaseTower({ settings, snap }: { settings: Settings; snap: Snap }) {
  const lit = settings.rgbOn && settings.powered && settings.brightness > 0;
  const motion = lit && settings.effect !== "solid" ? "fx-breathe" : "";
  const ringOn = settings.zones.ring.on && lit;
  const fansOn = settings.zones.fans.on && lit;
  const gpuOn = settings.zones.gpu.on && lit;
  const ramOn = settings.zones.ram.on && lit;
  const glow = (on: boolean, color: string, delay: string) =>
    glowStyle(on, color, settings.effect, settings.lightSpeed, delay, lit, settings.brightness);

  return (
    <div className="chassis">
      <div className="chassis-shell">
        <div className="chassis-mesh" />
        <span className="chassis-led" />
        <div className="chassis-bay">
          <div className="grid grid-cols-3 gap-1">
            {snap.fans.slice(0, 3).map((fan) => (
              <div
                key={fan.id}
                className={`flex items-center justify-center rounded-lg border border-line p-1 ${fansOn ? motion : "opacity-40"}`}
                style={glow(fansOn, LIGHTS[settings.zones.fans.color], "0.35s")}
              >
                <FanGlyph rpm={fan.rpm} max={fan.max} className="size-10 sm:size-12" />
              </div>
            ))}
          </div>
          <div className="flex flex-1 items-center gap-3 px-1">
            <div
              className={`grid size-16 place-items-center rounded-full border-2 sm:size-20 ${ringOn ? motion : "opacity-40"}`}
              style={glow(ringOn, LIGHTS[settings.zones.ring.color], "0s")}
            >
              <span className="text-xs font-medium tracking-widest">CPU</span>
            </div>
            <div className="flex h-16 gap-1 sm:h-20">
              {[0, 1].map((stick) => (
                <div
                  key={stick}
                  className={`w-3 rounded-sm border sm:w-4 ${ramOn ? motion : "opacity-40"}`}
                  style={glow(ramOn, LIGHTS[settings.zones.ram.color], "1.05s")}
                />
              ))}
            </div>
          </div>
          <div
            className={`flex h-12 items-center rounded-md border px-3 ${gpuOn ? motion : "opacity-40"}`}
            style={glow(gpuOn, LIGHTS[settings.zones.gpu.color], "0.7s")}
          >
            <span className="text-xs font-medium tracking-widest">GPU</span>
            <span className="ml-auto font-mono text-xs tabular-nums">{snap.gpuFanRpm > 0 ? snap.gpuFanRpm : "STOP"}</span>
          </div>
        </div>
      </div>
      <span className="foot foot-l" />
      <span className="foot foot-r" />
    </div>
  );
}
