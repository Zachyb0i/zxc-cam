import { FanGlyph } from "@/components/zxc/fans";
import { Eyebrow, Metric, Panel } from "@/components/zxc/ui";
import { CURVE_TEMPS, PRESETS, sampleCurve, toneText, type Preset } from "@/lib/rig";
import { useRig } from "@/lib/rig-context";

const PRESET_LIST: { id: Exclude<Preset, "custom">; label: string }[] = [
  { id: "silent", label: "Silent" },
  { id: "balanced", label: "Balanced" },
  { id: "performance", label: "Performance" },
];

export function Cooling() {
  const { live, settings, snap, applyPreset, setCurvePoint } = useRig();
  const dutyNow = sampleCurve(settings.curve, live.cpuTemp);
  const points = settings.curve
    .map((duty, i) => {
      const x = (i / 4) * 100;
      const y = 100 - duty;
      return `${x},${y}`;
    })
    .join(" ");
  const marker = Math.max(0, Math.min(100, ((live.cpuTemp - 30) / 60) * 100));

  return (
    <div className="flex flex-col gap-4">
      <div className="grid gap-3 sm:grid-cols-3">
        <Panel className="p-4">
          <Metric label="Coolant" value={live.liquid.toFixed(1)} unit="°C" tone={toneText(live.liquid)} />
        </Panel>
        <Panel className="p-4">
          <Metric label="CPU − liquid" value={(live.cpuTemp - live.liquid).toFixed(1)} unit="Δ°" />
        </Panel>
        <Panel className="p-4">
          <Metric label="Pump" value={String(snap.pumpRpm)} unit={`${Math.round(live.pump)}%`} />
        </Panel>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="grid gap-3 sm:grid-cols-2">
          {snap.fans.map((fan) => (
            <Panel key={fan.id} className="flex items-center gap-3 p-4">
              <div className="text-cyan">
                <FanGlyph rpm={fan.rpm} max={fan.max} className="size-16" />
              </div>
              <div className="min-w-0">
                <Eyebrow>{fan.role}</Eyebrow>
                <p className="mt-1 truncate text-sm text-fg">{fan.name}</p>
                <p className="font-mono text-lg tabular-nums text-fg">
                  {fan.rpm}
                  <span className="ml-1 text-xs text-muted">RPM</span>
                </p>
              </div>
            </Panel>
          ))}
        </div>

        <Panel className="p-4 sm:p-5">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <Eyebrow>Fan curve</Eyebrow>
              <p className="mt-1 text-sm text-muted">
                Duty {Math.round(dutyNow)}% at {live.cpuTemp.toFixed(0)}° package
                {settings.preset === "custom" ? " · custom" : ""}
              </p>
            </div>
            <div className="flex flex-wrap gap-2" role="group" aria-label="Fan preset">
              {PRESET_LIST.map((preset) => {
                const on = settings.preset === preset.id;
                return (
                  <button
                    key={preset.id}
                    type="button"
                    aria-pressed={on}
                    onClick={() => applyPreset(preset.id)}
                    className={`press h-11 rounded-control border px-3 text-sm ${
                      on ? "border-cyan text-cyan" : "border-line text-muted"
                    }`}
                  >
                    {preset.label}
                  </button>
                );
              })}
            </div>
          </div>

          <svg viewBox="0 0 100 100" className="mt-4 h-40 w-full" preserveAspectRatio="none" aria-hidden>
            {[25, 50, 75].map((y) => (
              <line key={y} x1="0" x2="100" y1={y} y2={y} stroke="var(--color-line)" strokeWidth="0.6" />
            ))}
            <polygon points={`0,100 ${points} 100,100`} fill="var(--color-cyan)" opacity="0.16" />
            <polyline points={points} fill="none" stroke="var(--color-cyan)" strokeWidth="1.6" vectorEffect="non-scaling-stroke" />
            <line x1={marker} x2={marker} y1="0" y2="100" stroke="var(--color-warn)" strokeWidth="0.8" />
            {settings.curve.map((duty, i) => {
              const x = (i / 4) * 100;
              const y = 100 - duty;
              return (
                <line
                  key={CURVE_TEMPS[i]}
                  x1={x}
                  x2={x}
                  y1={y - 3}
                  y2={y + 3}
                  stroke="var(--color-fg)"
                  strokeWidth="2"
                  vectorEffect="non-scaling-stroke"
                />
              );
            })}
          </svg>
          <div className="mt-1 grid grid-cols-5 font-mono text-xs text-muted tabular-nums">
            {CURVE_TEMPS.map((temp) => (
              <span key={temp} className="text-center">
                {temp}°
              </span>
            ))}
          </div>
          <div className="mt-2 grid gap-1 sm:grid-cols-5">
            {settings.curve.map((duty, i) => (
              <label key={CURVE_TEMPS[i]} className="block">
                <span className="mb-1 block text-center font-mono text-xs tabular-nums text-fg">{Math.round(duty)}%</span>
                <input
                  className="duty"
                  type="range"
                  min={15}
                  max={100}
                  value={Math.round(duty)}
                  aria-label={`Fan duty at ${CURVE_TEMPS[i]} degrees`}
                  onChange={(e) => setCurvePoint(i, Number(e.target.value))}
                />
              </label>
            ))}
          </div>
          <p className="text-xs text-muted">
            Balanced is {PRESETS.balanced.join(" / ")}%. Higher duty pulls package temperature down — the loop has mass,
            so give it a few seconds.
          </p>
        </Panel>
      </div>
    </div>
  );
}
