import { TraceSlot } from "@/components/zxc/trace-slot";
import { Bar, Eyebrow, Metric, Panel } from "@/components/zxc/ui";
import { BUILD, toneBar, toneText } from "@/lib/rig";
import { useRig } from "@/lib/rig-context";

export function CpuView() {
  const { live, snap } = useRig();
  const groups = [
    { id: "CCD0", note: "3D V-Cache", cores: snap.cores.filter((c) => c.ccd === 0) },
    { id: "CCD1", note: "Frequency", cores: snap.cores.filter((c) => c.ccd === 1) },
  ];

  return (
    <div className="flex flex-col gap-4">
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Panel className="p-4">
          <Metric label="Package" value={live.cpuTemp.toFixed(1)} unit="°C" tone={toneText(live.cpuTemp)} />
        </Panel>
        <Panel className="p-4">
          <Metric label="Effective" value={snap.cpuClock.toFixed(2)} unit="GHz" />
        </Panel>
        <Panel className="p-4">
          <Metric label="Vcore" value={snap.vcore.toFixed(3)} unit="V" />
        </Panel>
        <Panel className="p-4">
          <Metric label="Power" value={Math.round(live.cpuPower).toString()} unit={`/ ${BUILD.cpu.tdp} W TDP`} />
        </Panel>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {groups.map((group) => (
          <Panel key={group.id} className="p-4 sm:p-5">
            <div className="flex items-baseline justify-between gap-3">
              <Eyebrow>{group.id}</Eyebrow>
              <p className="text-xs text-muted">{group.note}</p>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {group.cores.map((core) => (
                <div key={core.index} className="rounded-control border border-line bg-bg p-2.5">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs text-muted">C{String(core.index).padStart(2, "0")}</span>
                    <span className="font-mono text-xs tabular-nums text-muted">{Math.round(core.load * 100)}%</span>
                  </div>
                  <p className={`mt-2 font-mono text-2xl tabular-nums leading-none ${toneText(core.temp)}`}>
                    {Math.round(core.temp)}°
                  </p>
                  <p className="mt-1 font-mono text-xs tabular-nums text-muted">{core.clock.toFixed(2)} GHz</p>
                  <div className="mt-2">
                    <Bar
                      value={core.load * 100}
                      tone={toneBar(core.temp)}
                      label={`Core ${core.index}`}
                    />
                  </div>
                </div>
              ))}
            </div>
          </Panel>
        ))}
      </div>

      <TraceSlot series="cpu" />
      <p className="text-sm text-muted">
        {BUILD.cpu.vendor} {BUILD.cpu.name} · socket AM5 · {BUILD.cpu.cores} cores / {BUILD.cpu.threads} threads.
        CCD0 carries the stacked cache and runs a few degrees warmer.
      </p>
    </div>
  );
}
