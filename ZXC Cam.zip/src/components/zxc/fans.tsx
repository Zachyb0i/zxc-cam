export function FanGlyph({
  rpm,
  max,
  className = "",
}: {
  rpm: number;
  max: number;
  className?: string;
}) {
  const ratio = Math.max(0, Math.min(1, max > 0 ? rpm / max : 0));
  const dur = rpm < 40 ? 0 : Math.max(0.32, 2.3 - ratio * 1.95);
  return (
    <svg viewBox="0 0 64 64" className={`text-current ${className}`} aria-hidden>
      <circle cx="32" cy="32" r="29" fill="none" stroke="currentColor" strokeOpacity="0.4" strokeWidth="2" />
      <g className={dur ? "fan-spin" : undefined} style={dur ? { animationDuration: `${dur}s` } : undefined}>
        {Array.from({ length: 7 }, (_, i) => (
          <path
            key={i}
            d="M32 33c4-8 5-16 0-20c-5 4-4 12 0 20z"
            fill="currentColor"
            transform={`rotate(${i * (360 / 7)} 32 32)`}
          />
        ))}
      </g>
      <circle cx="32" cy="32" r="5" fill="var(--color-bg)" stroke="currentColor" strokeWidth="1.6" />
    </svg>
  );
}
