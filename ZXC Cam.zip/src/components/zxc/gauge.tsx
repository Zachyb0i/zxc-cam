import { toneStroke, toneText } from "@/lib/rig";

const CX = 120;
const CY = 120;
const R = 86;
const CIRC = 2 * Math.PI * R;
const SWEEP = 0.75;

function tickPoint(frac: number, radius: number) {
  const deg = 135 + frac * 270;
  const rad = (deg * Math.PI) / 180;
  return [CX + radius * Math.cos(rad), CY + radius * Math.sin(rad)];
}

export function Gauge({
  label,
  chip,
  temp,
  delta,
  stats,
}: {
  label: string;
  chip: string;
  temp: number;
  delta: number;
  stats: { label: string; value: string }[];
}) {
  const pct = Math.max(0, Math.min(1, temp / 105));
  const stroke = toneStroke(temp);
  const dash = `${SWEEP * CIRC * pct} ${CIRC}`;
  const track = `${SWEEP * CIRC} ${CIRC}`;
  const moving = Math.abs(delta) >= 0.4;
  const sign = delta > 0 ? "+" : "−";

  return (
    <div className="flex flex-col items-center px-4 py-6 sm:px-6">
      <div className="relative size-56 sm:size-64">
        <svg viewBox="0 0 240 240" className="size-full" role="img" aria-label={`${label} ${Math.round(temp)} degrees`}>
          <circle
            cx={CX}
            cy={CY}
            r={R}
            fill="none"
            stroke="var(--color-line)"
            strokeWidth="10"
            strokeLinecap="round"
            strokeDasharray={track}
            transform={`rotate(135 ${CX} ${CY})`}
          />
          <circle
            cx={CX}
            cy={CY}
            r={R}
            fill="none"
            stroke={stroke}
            strokeWidth="10"
            strokeLinecap="round"
            strokeDasharray={dash}
            transform={`rotate(135 ${CX} ${CY})`}
            style={{ filter: `drop-shadow(0 0 8px ${stroke})` }}
          />
          {[0, 0.33, 0.66, 1].map((frac) => {
            const [x1, y1] = tickPoint(frac, 102);
            const [x2, y2] = tickPoint(frac, 110);
            return (
              <line
                key={frac}
                x1={x1}
                y1={y1}
                x2={x2}
                y2={y2}
                stroke="var(--color-muted)"
                strokeWidth="2"
                strokeLinecap="round"
              />
            );
          })}
        </svg>
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
          <p className={`font-mono text-6xl leading-none font-medium tabular-nums ${toneText(temp)}`}>
            {Math.round(temp)}
            <span className="text-2xl text-muted">°</span>
          </p>
          <p className="mt-2 text-xs font-medium tracking-widest text-muted uppercase">{label}</p>
        </div>
      </div>
      <p className="mt-1 text-center text-sm text-fg">{chip}</p>
      <p className="mt-1 font-mono text-xs tabular-nums text-muted">
        {moving ? `${sign}${Math.abs(delta).toFixed(1)}° / 30s` : "steady · 30s"}
      </p>
      <dl className="mt-5 grid w-full max-w-xs grid-cols-3 gap-2">
        {stats.map((stat) => (
          <div key={stat.label} className="text-center">
            <dt className="text-xs tracking-widest text-muted uppercase">{stat.label}</dt>
            <dd className="mt-1 font-mono text-sm tabular-nums text-fg">{stat.value}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}
