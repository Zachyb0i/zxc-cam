import { FanGlyph } from "@/components/zxc/fans";
import { TraceSlot } from "@/components/zxc/trace-slot";
import { Bar, Eyebrow, Metric, Panel } from "@/components/zxc/ui";
import { BUILD, toneText } from "@/lib/rig";
import { useRig } from "@/lib/rig-context";

export function GpuView() {
  const { live, snap } = useRig();
  const powerPct = (live.gpuPower / BUILD.gpu.tdp) * 100;
  const vramPct = (live.vram / BUILD.gpu.vram) * 100;
  const blocks = 16;

  return (
    <div className="flex flex-col gap-4">
      <div className="grid gap-4 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]">
        <Panel className="p-4 sm:p-5">
          <Eyebrow>Thermals</Eyebrow>
          <div className="mt-4 grid grid-cols-3 gap-3">
            <Metric label="Edge" value={live.gpuTemp.toFixed(1)} unit="°" tone={toneText(live.gpuTemp)} />
            <Metric label="Hotspot" value={snap.hotspot.toFixed(1)} unit="°" tone={toneText(snap.hotspot)} />
            <Metric label="Memory" value={snap.memJunction.toFixed(1)} unit="°" tone={toneText(snap.memJunction)} />
          </div>
          <div className="mt-6">
            <div className="mb-2 flex items-baseline justify-between">
              <Eyebrow>Power limit</Eyebrow>
              <p className="font-mono text-sm tabular-nums text-fg">
                {Math.round(live.gpuPower)} / {BUILD.gpu.tdp} W
              </p>
            </div>
            <Bar
              value={powerPct}
              tone={powerPct > 92 ? "bg-hot" : "bg-cyan"}
              label="GPU power"
            />
          </div>
          <div className="mt-6 grid grid-cols-2 gap-4">
            <Metric label="Core clock" value={Math.round(snap.gpuClock).toString()} unit="MHz" />
            <Metric label="Memory clock" value={Math.round(snap.memClock).toString()} unit="MHz" />
          </div>
        </Panel>

        <Panel className="flex flex-col gap-5 p-4 sm:p-5">
          <div className="flex items-center gap-4">
            <div className={snap.gpuFanOn ? "text-cyan" : "text-muted"}>
              <FanGlyph rpm={snap.gpuFanRpm} max={2200} className="size-20" />
            </div>
            <div>
              <Eyebrow>Cooler</Eyebrow>
              <p className="mt-1 font-mono text-2xl tabular-nums text-fg">
                {snap.gpuFanRpm}
                <span className="ml-1 text-xs text-muted">RPM</span>
              </p>
              <p className="text-sm text-muted">{snap.gpuFanOn ? "Fans tracking hotspot" : "Fan stop · under light load"}</p>
            </div>
          </div>
          <div>
            <div className="mb-2 flex items-baseline justify-between">
              <Eyebrow>VRAM</Eyebrow>
              <p className="font-mono text-sm tabular-nums text-muted">
                {live.vram.toFixed(1)} / {BUILD.gpu.vram} GB
              </p>
            </div>
            <div className="grid grid-cols-8 gap-1" aria-hidden>
              {Array.from({ length: blocks }, (_, i) => {
                const filled = (i + 1) / blocks <= vramPct / 100 + 0.001;
                return <span key={i} className={`h-8 rounded-sm ${filled ? "bg-cyan" : "bg-bg"}`} />;
              })}
            </div>
            <p className="mt-2 text-xs text-muted">
              {BUILD.gpu.mem} · {BUILD.gpu.bus}
            </p>
          </div>
          <div className="grid grid-cols-2 gap-3 border-t border-line pt-4">
            <Metric label="Load" value={`${Math.round(live.gpuLoad * 100)}`} unit="%" />
            <div>
              <p className="text-xs font-medium tracking-widest text-muted uppercase">Board</p>
              <p className="mt-1 text-sm text-fg">{BUILD.gpu.vendor}</p>
              <p className="text-sm text-muted">{BUILD.gpu.name}</p>
            </div>
          </div>
        </Panel>
      </div>
      <TraceSlot series="gpu" />
    </div>
  );
}
