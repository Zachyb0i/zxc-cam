import { CaseTower } from "@/components/zxc/case-tower";
import { Eyebrow, Panel } from "@/components/zxc/ui";
import { LIGHT_KEYS, LIGHTS, type Effect, type LightKey, type Settings } from "@/lib/rig";
import { useRig } from "@/lib/rig-context";

const EFFECTS: { id: Effect; label: string }[] = [
  { id: "solid", label: "Solid" },
  { id: "breathe", label: "Breathe" },
  { id: "wave", label: "Wave" },
  { id: "chase", label: "Color Chase" },
];

const ZONES: { id: keyof Settings["zones"]; label: string; hint: string }[] = [
  { id: "ring", label: "Pump ring", hint: "Cold plate" },
  { id: "fans", label: "Radiator", hint: "Three rings" },
  { id: "gpu", label: "Graphics", hint: "Edge accent" },
  { id: "ram", label: "Memory", hint: "Both DIMMs" },
];

const NAMES: Record<LightKey, string> = {
  cyan: "Voltage",
  ice: "Ice",
  bone: "Bone",
  amber: "Amber",
  coral: "Coral",
};

export function Lighting() {
  const { settings, snap, setEffect, setLightSpeed, setZone } = useRig();

  return (
    <div className="grid items-start gap-4 lg:grid-cols-3">
      <Panel className="p-4 lg:col-span-1">
        <Eyebrow>Prism</Eyebrow>
        <p className="mt-1 text-sm text-muted">Live preview of the zones on FORGE-01.</p>
        <div className="mt-4">
          <CaseTower settings={settings} snap={snap} />
        </div>
      </Panel>

      <div className="flex min-w-0 flex-col gap-4 lg:col-span-2">
        <Panel className="p-4 sm:p-5">
          <Eyebrow>Effect</Eyebrow>
          <div className="mt-3 flex flex-wrap gap-2" role="group" aria-label="Lighting effect">
            {EFFECTS.map((effect) => {
              const on = settings.effect === effect.id;
              return (
                <button
                  key={effect.id}
                  type="button"
                  aria-pressed={on}
                  onClick={() => setEffect(effect.id)}
                  className={`press h-11 rounded-control border px-4 text-sm ${
                    on ? "border-cyan bg-cyan text-bg" : "border-line text-muted"
                  }`}
                >
                  {effect.label}
                </button>
              );
            })}
          </div>
          <label className="mt-5 block">
            <span className="flex items-center justify-between text-sm text-muted">
              Speed
              <span className="font-mono tabular-nums text-fg">{settings.lightSpeed.toFixed(1)}×</span>
            </span>
            <input
              className="duty"
              type="range"
              min={0.5}
              max={2}
              step={0.1}
              value={settings.lightSpeed}
              aria-label="Lighting speed"
              onChange={(e) => setLightSpeed(Number(e.target.value))}
            />
          </label>
        </Panel>

        <div className="grid gap-3 sm:grid-cols-2">
          {ZONES.map((zone) => {
            const state = settings.zones[zone.id];
            return (
              <Panel key={zone.id} className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-medium text-fg">{zone.label}</p>
                    <p className="text-xs text-muted">{zone.hint}</p>
                  </div>
                  <button
                    type="button"
                    aria-pressed={state.on}
                    aria-label={`${zone.label} ${state.on ? "on" : "off"}`}
                    onClick={() => setZone(zone.id, { on: !state.on })}
                    className={`press relative h-8 w-14 rounded-full border ${
                      state.on ? "border-cyan bg-cyan" : "border-line bg-bg"
                    }`}
                  >
                    <span
                      className={`absolute top-1 left-0 size-5 rounded-full transition-transform duration-150 ${
                        state.on ? "translate-x-7 bg-bg" : "translate-x-1 bg-fg"
                      }`}
                    />
                  </button>
                </div>
                <div className="mt-3 flex gap-2" role="group" aria-label={`${zone.label} color`}>
                  {LIGHT_KEYS.map((key) => {
                    const selected = state.color === key;
                    return (
                      <button
                        key={key}
                        type="button"
                        aria-label={NAMES[key]}
                        aria-pressed={selected}
                        disabled={!state.on}
                        onClick={() => setZone(zone.id, { color: key })}
                        className={`press size-11 rounded-full border-2 ${selected ? "border-fg" : "border-transparent"} disabled:opacity-40`}
                        style={{ background: LIGHTS[key] }}
                      />
                    );
                  })}
                </div>
              </Panel>
            );
          })}
        </div>
      </div>
    </div>
  );
}
