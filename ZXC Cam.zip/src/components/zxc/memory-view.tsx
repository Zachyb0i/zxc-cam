import { Bar, Eyebrow, Metric, Panel } from "@/components/zxc/ui";
import { BUILD, LIGHTS, toneText } from "@/lib/rig";
import { useRig } from "@/lib/rig-context";

export function MemoryView() {
  const { live, settings } = useRig();
  const pct = (live.ramUsed / BUILD.ram.capacity) * 100;
  const dimmTemp = live.liquid + 6 + (live.ramUsed / BUILD.ram.capacity) * 8;
  const glow = settings.zones.ram.on ? LIGHTS[settings.zones.ram.color] : "var(--color-muted)";

  return (
    <div className="flex flex-col gap-4">
      <div className="grid gap-3 sm:grid-cols-3">
        <Panel className="p-4">
          <Metric label="In use" value={live.ramUsed.toFixed(1)} unit="GB" />
        </Panel>
        <Panel className="p-4">
          <Metric label="Available" value={(BUILD.ram.capacity - live.ramUsed).toFixed(1)} unit="GB" />
        </Panel>
        <Panel className="p-4">
          <Metric label="DIMM" value={dimmTemp.toFixed(1)} unit="°C" tone={toneText(dimmTemp)} />
        </Panel>
      </div>

      <Panel className="p-4 sm:p-5">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <Eyebrow>Kit</Eyebrow>
            <h2 className="mt-1 text-lg font-semibold text-fg">{BUILD.ram.kit}</h2>
            <p className="text-sm text-muted">
              {BUILD.ram.speed} · {BUILD.ram.timings} · EXPO · dual channel
            </p>
          </div>
          <p className="font-mono text-sm tabular-nums text-muted">
            {Math.round(pct)}% of {BUILD.ram.capacity} GB
          </p>
        </div>
        <div className="mt-4">
          <Bar value={pct} label="Memory used" />
        </div>
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          {[0, 1].map((slot) => (
            <div key={slot} className="rounded-control border border-line bg-bg p-4">
              <div className="mb-3 flex items-center justify-between">
                <p className="text-sm text-fg">DIMM {String.fromCharCode(65 + slot)}2</p>
                <p className="font-mono text-xs text-muted">32 GB</p>
              </div>
              <div className="relative h-24 overflow-hidden rounded-md border border-line bg-surface">
                <span className="absolute top-0 left-8 h-3 w-10 bg-bg" />
                <div className="flex h-full items-center gap-2 px-4">
                  {Array.from({ length: 8 }, (_, i) => (
                    <span
                      key={i}
                      className="h-12 flex-1 rounded-sm border"
                      style={{
                        borderColor: glow,
                        background: `color-mix(in oklab, ${glow} ${18 + (i % 3) * 8}%, var(--color-bg))`,
                        boxShadow: settings.zones.ram.on
                          ? `0 0 12px color-mix(in oklab, ${glow} 45%, transparent)`
                          : undefined,
                      }}
                    />
                  ))}
                </div>
              </div>
              <p className="mt-2 text-xs text-muted">Slot {slot === 0 ? "A2" : "B2"} · populated</p>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}
