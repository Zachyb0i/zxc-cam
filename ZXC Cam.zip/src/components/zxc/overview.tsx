import type { ReactNode } from "react";
import { Fan, Grid2x2, SlidersHorizontal } from "lucide-react";
import { BUILD, toneStroke, type Effect } from "@/lib/rig";
import { useRig } from "@/lib/rig-context";

function Ring({
  label,
  percent,
  stroke,
}: {
  label: string;
  percent: number;
  stroke: string;
}) {
  const r = 34;
  const c = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(1, percent));
  return (
    <div className="relative size-24 shrink-0 sm:size-28">
      <svg viewBox="0 0 100 100" className="size-full -rotate-90" role="img" aria-label={label}>
        <circle cx="50" cy="50" r="46" fill="none" stroke="color-mix(in oklab, var(--color-cyan) 35%, transparent)" strokeWidth="2" />
        <circle cx="50" cy="50" r={r} fill="none" stroke="color-mix(in oklab, var(--color-cyan) 18%, transparent)" strokeWidth="9" />
        <circle
          cx="50"
          cy="50"
          r={r}
          fill="none"
          stroke={stroke}
          strokeWidth="9"
          strokeLinecap="round"
          strokeDasharray={`${pct * c} ${c}`}
          style={{ filter: `drop-shadow(0 0 6px ${stroke})` }}
        />
      </svg>
      <p className="absolute inset-0 grid place-items-center font-mono text-sm font-medium tabular-nums text-fg sm:text-base">
        {label}
      </p>
    </div>
  );
}

function Spark({ values, stroke }: { values: number[]; stroke: string }) {
  if (values.length < 2) return null;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min || 1;
  const d = values
    .map((value, i) => {
      const x = (i / (values.length - 1)) * 100;
      const y = 30 - ((value - min) / span) * 24;
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
    })
    .join(" ");
  const end = values.length - 1;
  const ex = 100;
  const ey = 30 - ((values[end]! - min) / span) * 24;
  return (
    <svg viewBox="0 0 100 36" className="h-9 w-28 sm:w-36" aria-hidden>
      <path d={d} fill="none" stroke={stroke} strokeWidth="1.8" vectorEffect="non-scaling-stroke" />
      <circle cx={ex} cy={ey} r="2.2" fill={stroke} />
    </svg>
  );
}

function Toggle({
  on,
  label,
  onClick,
}: {
  on: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-pressed={on}
      aria-label={label}
      onClick={onClick}
      className={`press relative h-8 w-14 shrink-0 rounded-full border ${on ? "border-violet bg-violet" : "border-line bg-bg"}`}
    >
      <span
        className={`absolute top-1 left-0 size-5 rounded-full transition-transform duration-150 ${
          on ? "translate-x-7 bg-fg" : "translate-x-1 bg-muted"
        }`}
      />
    </button>
  );
}

function CoolerMark() {
  return (
    <svg viewBox="0 0 120 78" className="h-16 w-28 shrink-0" aria-hidden>
      <rect x="8" y="10" width="104" height="58" rx="10" fill="color-mix(in oklab, white 16%, transparent)" stroke="var(--color-fg)" strokeOpacity="0.7" />
      <circle cx="60" cy="39" r="18" fill="none" stroke="var(--color-fg)" strokeOpacity="0.85" />
      <circle cx="60" cy="39" r="5" fill="var(--color-fg)" />
      {[0, 60, 120, 180, 240, 300].map((deg) => (
        <line
          key={deg}
          x1="60"
          y1="39"
          x2="60"
          y2="24"
          stroke="var(--color-fg)"
          strokeWidth="2"
          transform={`rotate(${deg} 60 39)`}
        />
      ))}
    </svg>
  );
}

const RPM = [
  { id: "low", label: "AI Low Mode" },
  { id: "med", label: "AI Medium Mode" },
  { id: "high", label: "AI High Mode" },
  { id: "custom", label: "Custom" },
  { id: "manual", label: "Manual Mode" },
] as const;

export function Overview() {
  const { live, settings, snap, setPowered, setRpm, setManualDuty, setHoldBand, setRgbOn, setEffect, setLightSpeed, setBrightness } =
    useRig();
  const history = live.history.slice(-28);
  const ccd = (id: number) => {
    const cores = snap.cores.filter((core) => core.ccd === id);
    const avg = cores.reduce((sum, core) => sum + core.clock, 0) / cores.length;
    return Math.round(avg * 1000);
  };
  const mode = settings.manual
    ? "manual"
    : settings.preset === "silent"
      ? "low"
      : settings.preset === "balanced"
        ? "med"
        : settings.preset === "performance"
          ? "high"
          : "custom";
  const ramPct = (live.ramUsed / BUILD.ram.capacity) * 100;
  const vramPct = (live.vram / BUILD.gpu.vram) * 100;
  const speedShown = Math.round(((settings.lightSpeed - 0.5) / 1.5) * 100);

  return (
    <div className="flex flex-col gap-4">
      <section className="device-banner flex flex-wrap items-center gap-4 px-4 py-4 sm:px-5">
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-3">
            <p className="text-2xl font-semibold tracking-tight">ZXC</p>
            <Toggle on={settings.powered} label={settings.powered ? "Cooler on" : "Cooler off"} onClick={() => setPowered(!settings.powered)} />
            <span className="text-sm font-medium tracking-wide">{settings.powered ? "ON" : "OFF"}</span>
          </div>
          <p className="mt-2 text-sm opacity-80">Link active</p>
          <dl className="mt-3 grid max-w-md grid-cols-3 gap-3 font-mono text-xs">
            <div>
              <dt className="opacity-70">SN Code</dt>
              <dd className="mt-1 text-sm text-fg">ZX4G36019</dd>
            </div>
            <div>
              <dt className="opacity-70">PID</dt>
              <dd className="mt-1 text-sm text-fg">C360</dd>
            </div>
            <div>
              <dt className="opacity-70">VID</dt>
              <dd className="mt-1 text-sm text-fg">5A21</dd>
            </div>
          </dl>
        </div>
        <div className="ml-auto flex items-center gap-3">
          <div className="text-right">
            <p className="text-lg font-semibold">Glacier 360</p>
            <p className="text-sm opacity-80">Desktop cooler</p>
          </div>
          <CoolerMark />
        </div>
      </section>

      <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1.45fr)_minmax(18rem,0.8fr)]">
        <section className="panel p-4 sm:p-5">
          <h2 className="text-lg font-semibold">Hardware Status</h2>

          <SensorRow
            title="CPU"
            load={live.cpuLoad}
            temp={live.cpuTemp}
            freqLabel="Frequency"
            freq={
              <>
                <p>CCD0 {ccd(0)} MHZ</p>
                <p>CCD1 {ccd(1)} MHZ</p>
              </>
            }
            power={live.cpuPower}
            tempSeries={history.map((sample) => sample.cpu)}
            powerSeries={history.map((sample) => sample.cpuW)}
          />
          <SensorRow
            title="GPU"
            load={live.gpuLoad}
            temp={live.gpuTemp}
            freqLabel="Frequency"
            freq={<p>{Math.round(snap.gpuClock)} MHZ</p>}
            power={live.gpuPower}
            tempSeries={history.map((sample) => sample.gpu)}
            powerSeries={history.map((sample) => sample.gpuW)}
          />

          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            <SlantMeter label="DRAM" pct={ramPct} detail={`${Math.round(ramPct)}%  ${live.ramUsed.toFixed(0)} / ${BUILD.ram.capacity} GB`} />
            <SlantMeter label="VRAM" pct={vramPct} detail={`${Math.round(vramPct)}%  ${live.vram.toFixed(0)} / ${BUILD.gpu.vram} GB`} />
          </div>
        </section>

        <div className="flex flex-col gap-4">
          <section className="panel p-4 sm:p-5">
            <h2 className="text-lg font-semibold">RPM Mode</h2>
            <div className="mt-4 grid grid-cols-3 gap-2">
              {RPM.map((item) => {
                const on = mode === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    aria-pressed={on}
                    onClick={() => setRpm(item.id)}
                    className={`press flex min-h-20 flex-col items-center justify-center gap-2 rounded-control border px-2 py-3 text-center text-xs ${
                      on ? "rpm-on" : "border-line text-muted"
                    }`}
                  >
                    {item.id === "custom" ? (
                      <Grid2x2 className="size-6" strokeWidth={1.75} />
                    ) : item.id === "manual" ? (
                      <SlidersHorizontal className="size-6" strokeWidth={1.75} />
                    ) : (
                      <Fan className="size-6" strokeWidth={1.75} />
                    )}
                    {item.label}
                  </button>
                );
              })}
            </div>
            <p className="mt-4 font-mono text-sm text-fg">Current Speed: {Math.round(live.fanDuty)}%</p>
            {mode === "manual" ? (
              <label className="mt-2 block">
                <span className="text-xs text-muted">Manual duty</span>
                <input
                  className="duty"
                  type="range"
                  min={0}
                  max={100}
                  value={Math.round(settings.manualDuty)}
                  aria-label="Manual fan duty"
                  onChange={(e) => setManualDuty(Number(e.target.value))}
                />
              </label>
            ) : null}
            <label className="mt-3 flex items-start gap-2 text-sm text-muted">
              <input
                type="checkbox"
                className="mt-1 size-4 accent-violet"
                checked={settings.holdBand}
                onChange={(e) => setHoldBand(e.target.checked)}
              />
              Speed does not change when temperature is ±3°C
            </label>
          </section>

          <section className="panel p-4 sm:p-5">
            <div className="flex items-center justify-between gap-3">
              <h2 className="text-lg font-semibold">RGB Lighting Control</h2>
              <Toggle on={settings.rgbOn && settings.powered} label="RGB lighting" onClick={() => setRgbOn(!settings.rgbOn)} />
            </div>
            <label className="mt-4 block text-sm text-muted">
              Mode
              <select
                value={settings.effect}
                onChange={(e) => setEffect(e.target.value as Effect)}
                className="mt-2 h-11 w-full rounded-control border border-line bg-bg px-3 text-base text-fg"
              >
                <option value="solid">Solid</option>
                <option value="breathe">Breathe</option>
                <option value="wave">Wave</option>
                <option value="chase">Color Chase</option>
              </select>
            </label>
            <SliderRow
              label="Brightness"
              value={settings.brightness}
              min={0}
              max={100}
              onChange={setBrightness}
            />
            <SliderRow
              label="Speed"
              value={speedShown}
              min={0}
              max={100}
              onChange={(value) => setLightSpeed(0.5 + (value / 100) * 1.5)}
            />
          </section>
        </div>
      </div>
    </div>
  );
}

function SensorRow({
  title,
  load,
  temp,
  freqLabel,
  freq,
  power,
  tempSeries,
  powerSeries,
}: {
  title: string;
  load: number;
  temp: number;
  freqLabel: string;
  freq: ReactNode;
  power: number;
  tempSeries: number[];
  powerSeries: number[];
}) {
  const tempStroke = toneStroke(temp);
  return (
    <div className="mt-5 border-t border-line pt-4">
      <p className="text-sm font-medium tracking-wide text-fg">{title}</p>
      <div className="mt-3 flex flex-wrap items-center gap-4">
        <Ring label={`${Math.round(load * 100)}%`} percent={load} stroke="var(--color-cyan)" />
        <Ring label={`${Math.round(temp)}°C`} percent={Math.min(1, temp / 105)} stroke={tempStroke} />
        <div className="grid min-w-40 flex-1 gap-3 sm:grid-cols-2">
          <div>
            <div className="flex items-center gap-2 text-violet">
              <Spark values={tempSeries} stroke="var(--color-violet)" />
            </div>
            <p className="text-xs text-muted">{freqLabel}</p>
            <div className="font-mono text-sm tabular-nums text-fg">{freq}</div>
          </div>
          <div>
            <Spark values={powerSeries} stroke="var(--color-cyan)" />
            <p className="text-xs text-muted">Thermal Power Consumption</p>
            <p className="font-mono text-sm tabular-nums text-fg">{Math.round(power)} W</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SlantMeter({ label, pct, detail }: { label: string; pct: number; detail: string }) {
  return (
    <div className="flex items-center gap-3">
      <p className="w-12 text-xs font-medium tracking-wide text-fg">{label}</p>
      <div className="slant-track relative min-w-0 flex-1">
        <div className="slant-fill" style={{ width: `${Math.max(8, Math.min(100, pct))}%` }} />
        <p className="absolute inset-0 grid place-items-center font-mono text-xs tabular-nums text-fg">{detail}</p>
      </div>
    </div>
  );
}

function SliderRow({
  label,
  value,
  min,
  max,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (value: number) => void;
}) {
  return (
    <label className="mt-3 grid grid-cols-[5.5rem_minmax(0,1fr)_3rem] items-center gap-2 text-sm text-muted">
      {label}
      <input
        className="duty"
        type="range"
        min={min}
        max={max}
        value={Math.round(value)}
        aria-label={label}
        onChange={(e) => onChange(Number(e.target.value))}
      />
      <span className="rounded-control border border-line bg-bg py-2 text-center font-mono text-sm tabular-nums text-fg">
        {Math.round(value)}
      </span>
    </label>
  );
}
