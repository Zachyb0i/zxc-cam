import { useEffect, useRef, useState } from "react";
import {
  Cpu,
  Fan,
  Gauge,
  HardDrive,
  Lightbulb,
  Maximize2,
  MemoryStick,
  Minimize2,
  Monitor,
  SlidersHorizontal,
} from "lucide-react";
import { Cooling } from "@/components/zxc/cooling";
import { CpuView } from "@/components/zxc/cpu-view";
import { GpuView } from "@/components/zxc/gpu-view";
import { Lighting } from "@/components/zxc/lighting";
import { MemoryView } from "@/components/zxc/memory-view";
import { Overview } from "@/components/zxc/overview";
import { StorageView } from "@/components/zxc/storage-view";
import { BUILD, clamp, formatUptime, type ViewId } from "@/lib/rig";
import { useRig } from "@/lib/rig-context";

const NAV: { id: ViewId; label: string; icon: typeof Gauge }[] = [
  { id: "overview", label: "Overview", icon: Gauge },
  { id: "cooling", label: "Cooling", icon: Fan },
  { id: "cpu", label: "Processor", icon: Cpu },
  { id: "gpu", label: "Graphics", icon: Monitor },
  { id: "memory", label: "Memory", icon: MemoryStick },
  { id: "storage", label: "Storage", icon: HardDrive },
  { id: "lighting", label: "Lighting", icon: Lightbulb },
];

function Mark() {
  return (
    <svg viewBox="0 0 36 36" className="size-9 shrink-0" aria-hidden>
      <rect x="0.5" y="0.5" width="35" height="35" rx="10" fill="var(--color-surface)" stroke="var(--color-line)" />
      <path
        d="M10 12h16L10 24h16"
        fill="none"
        stroke="var(--color-cyan)"
        strokeWidth="2.2"
        strokeLinejoin="round"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function Shell() {
  const { live, settings, snap, view, setView, setRigName, setAlerts, resetTuning } = useRig();
  const [limitsOpen, setLimitsOpen] = useState(false);
  const [isFull, setIsFull] = useState(false);
  const limitsRef = useRef<HTMLDivElement>(null);
  const cpuHot = live.cpuTemp >= settings.cpuAlert;
  const gpuHot = live.gpuTemp >= settings.gpuAlert;

  useEffect(() => {
    const sync = () => setIsFull(document.fullscreenElement != null);
    document.addEventListener("fullscreenchange", sync);
    return () => document.removeEventListener("fullscreenchange", sync);
  }, []);

  async function toggleFull() {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await document.documentElement.requestFullscreen();
    } catch {
      /* fullscreen can be denied; the button stays usable */
    }
  }

  useEffect(() => {
    if (!limitsOpen) return;
    const onPointer = (event: PointerEvent) => {
      if (!limitsRef.current?.contains(event.target as Node)) setLimitsOpen(false);
    };
    document.addEventListener("pointerdown", onPointer);
    return () => document.removeEventListener("pointerdown", onPointer);
  }, [limitsOpen]);

  const page = {
    overview: <Overview />,
    cooling: <Cooling />,
    cpu: <CpuView />,
    gpu: <GpuView />,
    memory: <MemoryView />,
    storage: <StorageView />,
    lighting: <Lighting />,
  }[view];

  return (
    <div className="relative min-h-dvh">
      <div className="mx-auto flex min-h-dvh w-full max-w-[1440px]">
        <aside className="sticky top-0 hidden h-dvh w-56 shrink-0 flex-col border-r border-line px-3 py-5 md:flex">
          <div className="flex items-center gap-3 px-2">
            <Mark />
            <div>
              <p className="text-base leading-none font-semibold tracking-wide">ZXC</p>
              <p className="mt-1 text-xs tracking-widest text-muted uppercase">Cam</p>
            </div>
          </div>
          <nav className="mt-8 flex flex-col gap-1" aria-label="Sections">
            {NAV.map((item) => {
              const on = view === item.id;
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  type="button"
                  aria-current={on ? "page" : undefined}
                  onClick={() => setView(item.id)}
                  className={`press flex h-11 items-center gap-3 rounded-control border-l-2 px-3 text-left text-sm ${
                    on ? "border-cyan bg-raised text-fg" : "border-transparent text-muted hover:bg-raised hover:text-fg"
                  }`}
                >
                  <Icon className="size-4" strokeWidth={1.75} />
                  {item.label}
                </button>
              );
            })}
          </nav>
          <div className="mt-auto px-3">
            <p className="text-xs tracking-widest text-muted uppercase">Showcase link</p>
            <p className="mt-1 font-mono text-xs text-muted">12 probes · 400 ms</p>
            <p className="mt-2 text-xs text-muted">Thermal model of this rig, not the device you're on.</p>
          </div>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col">
          <header className="topbar sticky top-0 z-20 border-b border-line">
            <div className="flex flex-wrap items-center gap-3 px-4 py-3 md:px-6">
              <div className="flex min-w-0 items-center gap-3 md:hidden">
                <Mark />
              </div>
              <h1 className="sr-only">ZXC Cam</h1>
              <div className="min-w-0">
                <label className="block text-xs tracking-widest text-muted uppercase" htmlFor="rig-name">
                  Rig
                </label>
                <input
                  id="rig-name"
                  value={settings.rigName}
                  spellCheck={false}
                  maxLength={18}
                  aria-label="Rig name"
                  onChange={(e) => setRigName(e.target.value)}
                  onBlur={() => {
                    if (!settings.rigName.trim()) setRigName("FORGE-01");
                  }}
                  className="w-36 bg-transparent text-base font-semibold tracking-wide text-fg outline-none"
                />
              </div>
              <div className="ml-auto flex items-center gap-3">
                <p className="hidden font-mono text-xs tabular-nums text-muted sm:block">{formatUptime(snap.uptime)}</p>
                <span className="flex items-center gap-2 text-xs tracking-widest text-cyan uppercase">
                  <span className="relative flex size-2">
                    <span className="live-ping absolute inline-flex size-full rounded-full bg-cyan opacity-70" />
                    <span className="relative size-2 rounded-full bg-cyan" />
                  </span>
                  Live
                </span>
                <button
                  type="button"
                  onClick={() => void toggleFull()}
                  aria-pressed={isFull}
                  className="press flex h-11 items-center gap-2 rounded-control border border-cyan px-3 text-sm text-fg"
                >
                  {isFull ? <Minimize2 className="size-4" /> : <Maximize2 className="size-4" />}
                  <span className="hidden sm:inline">{isFull ? "Exit" : "Full screen"}</span>
                </button>
                <div className="relative" ref={limitsRef}>
                  <button
                    type="button"
                    aria-expanded={limitsOpen}
                    aria-label="Thermal limits"
                    onClick={() => setLimitsOpen((v) => !v)}
                    className="press grid size-11 place-items-center rounded-control border border-line text-muted hover:text-fg"
                  >
                    <SlidersHorizontal className="size-4" />
                  </button>
                  {limitsOpen ? (
                    <div className="panel absolute right-0 z-30 mt-2 w-72 p-4">
                      <p className="text-sm font-medium text-fg">Thermal limits</p>
                      <p className="mt-1 text-xs text-muted">Alerts fire when a package crosses the line.</p>
                      <label className="mt-3 flex items-center justify-between gap-3 text-sm text-muted">
                        CPU
                        <input
                          type="number"
                          min={70}
                          max={105}
                          value={Math.round(settings.cpuAlert)}
                          onChange={(e) => {
                            const n = Number(e.target.value);
                            if (Number.isFinite(n)) setAlerts(n, settings.gpuAlert);
                          }}
                          onBlur={(e) => setAlerts(clamp(Number(e.target.value) || 90, 70, 105), settings.gpuAlert)}
                          className="h-11 w-20 rounded-control border border-line bg-bg px-2 text-center font-mono text-base text-fg"
                        />
                      </label>
                      <label className="mt-2 flex items-center justify-between gap-3 text-sm text-muted">
                        GPU
                        <input
                          type="number"
                          min={70}
                          max={105}
                          value={Math.round(settings.gpuAlert)}
                          onChange={(e) => {
                            const n = Number(e.target.value);
                            if (Number.isFinite(n)) setAlerts(settings.cpuAlert, n);
                          }}
                          onBlur={(e) => setAlerts(settings.cpuAlert, clamp(Number(e.target.value) || 85, 70, 105))}
                          className="h-11 w-20 rounded-control border border-line bg-bg px-2 text-center font-mono text-base text-fg"
                        />
                      </label>
                      <button
                        type="button"
                        onClick={() => {
                          resetTuning();
                          setLimitsOpen(false);
                        }}
                        className="press mt-3 h-11 w-full rounded-control border border-line text-sm text-muted hover:text-fg"
                      >
                        Reset curve and lighting
                      </button>
                    </div>
                  ) : null}
                </div>
              </div>
            </div>
            <nav className="flex gap-1 overflow-x-auto border-t border-line px-3 py-2 md:hidden" aria-label="Sections">
              {NAV.map((item) => {
                const on = view === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    aria-current={on ? "page" : undefined}
                    onClick={() => setView(item.id)}
                    className={`press h-11 shrink-0 rounded-control px-3 text-sm ${
                      on ? "bg-raised text-fg" : "text-muted"
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
            </nav>
          </header>

          {cpuHot || gpuHot ? (
            <div className="alert-bar px-4 py-3 text-sm md:px-6" role="status">
              <p>
                {cpuHot ? `CPU package ${live.cpuTemp.toFixed(0)}° is past ${Math.round(settings.cpuAlert)}°. ` : ""}
                {gpuHot ? `GPU edge ${live.gpuTemp.toFixed(0)}° is past ${Math.round(settings.gpuAlert)}°. ` : ""}
                <button type="button" className="underline" onClick={() => setView("cooling")}>
                  Open cooling
                </button>
              </p>
            </div>
          ) : null}

          <main className="min-w-0 flex-1 px-4 py-5 md:px-6 md:py-6">
            <div key={view} className="view-enter">
              {page}
            </div>
            <p className="mt-6 text-xs text-muted">
              {settings.rigName || "FORGE-01"} · {BUILD.cpu.name} · {BUILD.gpu.name}
            </p>
          </main>
        </div>
      </div>
    </div>
  );
}
