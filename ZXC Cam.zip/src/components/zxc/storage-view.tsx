import { Bar, Eyebrow, Metric, Panel } from "@/components/zxc/ui";
import { toneText } from "@/lib/rig";
import { useRig } from "@/lib/rig-context";

export function StorageView() {
  const { snap } = useRig();

  return (
    <div className="flex flex-col gap-4">
      {snap.drives.map((drive) => {
        const usedGb = drive.capacityGb * drive.used;
        return (
          <Panel key={drive.id} className="p-4 sm:p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span
                    className={`size-2 rounded-full ${drive.activity > 0.15 ? "bg-cyan" : "bg-line"}`}
                    aria-hidden
                  />
                  <Eyebrow>{drive.kind}</Eyebrow>
                </div>
                <h2 className="mt-1 truncate text-lg font-semibold text-fg">{drive.name}</h2>
                <p className="text-sm text-muted">{drive.iface}</p>
              </div>
              <Metric label="Drive" value={drive.temp.toFixed(1)} unit="°C" tone={toneText(drive.temp)} />
            </div>
            <div className="mt-5 grid gap-4 sm:grid-cols-3">
              <div>
                <p className="text-xs tracking-widest text-muted uppercase">Read</p>
                <p className="mt-1 font-mono text-xl tabular-nums text-fg">
                  {Math.round(drive.read)}
                  <span className="ml-1 text-xs text-muted">MB/s</span>
                </p>
              </div>
              <div>
                <p className="text-xs tracking-widest text-muted uppercase">Write</p>
                <p className="mt-1 font-mono text-xl tabular-nums text-fg">
                  {Math.round(drive.write)}
                  <span className="ml-1 text-xs text-muted">MB/s</span>
                </p>
              </div>
              <div>
                <p className="text-xs tracking-widest text-muted uppercase">Activity</p>
                <p className="mt-1 font-mono text-xl tabular-nums text-fg">{Math.round(drive.activity * 100)}%</p>
              </div>
            </div>
            <div className="mt-4">
              <div className="mb-2 flex justify-between text-xs text-muted">
                <span>
                  {Math.round(usedGb)} GB used
                </span>
                <span>{drive.capacityGb / 1000} TB</span>
              </div>
              <Bar value={drive.used * 100} label={`${drive.name} capacity`} />
            </div>
          </Panel>
        );
      })}
    </div>
  );
}
