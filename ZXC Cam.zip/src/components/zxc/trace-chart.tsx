import { useRig } from "@/lib/rig-context";
import { Area, AreaChart, CartesianGrid, Tooltip, YAxis } from "recharts";

type TipPayload = { dataKey?: string | number; value?: number; color?: string };

function Tip({
  active,
  payload,
  unit,
}: {
  active?: boolean;
  payload?: TipPayload[];
  unit: string;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-control border border-line bg-raised px-3 py-2 font-mono text-xs text-fg">
      {payload.map((item) => (
        <p key={String(item.dataKey)} className="tabular-nums">
          <span style={{ color: item.color }}>{item.dataKey === "a" ? "CPU" : "GPU"}</span>
          {"  "}
          {typeof item.value === "number" ? item.value.toFixed(item.value > 120 ? 0 : 1) : "–"}
          {unit}
        </p>
      ))}
    </div>
  );
}

export function TraceChart({
  width,
  height,
  mode,
  series,
}: {
  width: number;
  height: number;
  mode: "temp" | "power";
  series: "both" | "cpu" | "gpu";
}) {
  const { live } = useRig();
  const data = live.history.map((sample, i) => ({
    i,
    a: mode === "temp" ? sample.cpu : sample.cpuW,
    b: mode === "temp" ? sample.gpu : sample.gpuW,
  }));
  const domain: [number, number] = mode === "temp" ? [25, 100] : [0, 640];
  const unit = mode === "temp" ? "°" : "W";
  const showA = series !== "gpu";
  const showB = series !== "cpu";

  return (
    <AreaChart width={width} height={height} data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
      <CartesianGrid vertical={false} stroke="var(--color-line)" strokeDasharray="3 8" />
      <YAxis
        domain={domain}
        width={40}
        tick={{ fill: "var(--color-muted)", fontSize: 11, fontFamily: "IBM Plex Mono, monospace" }}
        axisLine={false}
        tickLine={false}
        tickCount={5}
      />
      <Tooltip content={<Tip unit={unit} />} />
      {showA ? (
        <Area
          type="monotone"
          dataKey="a"
          stroke="var(--color-cyan)"
          fill="var(--color-cyan)"
          fillOpacity={0.16}
          strokeWidth={2}
          isAnimationActive={false}
          dot={false}
        />
      ) : null}
      {showB ? (
        <Area
          type="monotone"
          dataKey="b"
          stroke="var(--color-hot)"
          fill="var(--color-hot)"
          fillOpacity={0.12}
          strokeWidth={2}
          isAnimationActive={false}
          dot={false}
        />
      ) : null}
    </AreaChart>
  );
}
