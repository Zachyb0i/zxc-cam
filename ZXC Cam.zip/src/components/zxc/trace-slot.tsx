import { useEffect, useRef, useState } from "react";
import { Eyebrow, Panel } from "@/components/zxc/ui";

type Mod = typeof import("./trace-chart");

export function TraceSlot({ series = "both" }: { series?: "both" | "cpu" | "gpu" }) {
  const ref = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(0);
  const [mod, setMod] = useState<Mod | null>(null);
  const [mode, setMode] = useState<"temp" | "power">("temp");

  useEffect(() => {
    let on = true;
    void import("./trace-chart").then((m) => {
      if (on) setMod(m);
    });
    return () => {
      on = false;
    };
  }, []);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const apply = () => setWidth(Math.floor(el.clientWidth));
    apply();
    const ro = new ResizeObserver(apply);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  return (
    <Panel className="p-4 sm:p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <Eyebrow>Trace · 30 seconds</Eyebrow>
          <p className="mt-1 text-sm text-muted">{mode === "temp" ? "Package temperature" : "Board power"}</p>
        </div>
        <div className="flex items-center gap-3">
          {series !== "gpu" ? (
            <span className="flex items-center gap-1.5 text-xs text-muted">
              <span className="size-2 rounded-full bg-cyan" /> CPU
            </span>
          ) : null}
          {series !== "cpu" ? (
            <span className="flex items-center gap-1.5 text-xs text-muted">
              <span className="size-2 rounded-full bg-hot" /> GPU
            </span>
          ) : null}
          <div className="flex rounded-control border border-line p-1" role="group" aria-label="Trace mode">
            {(["temp", "power"] as const).map((id) => (
              <button
                key={id}
                type="button"
                aria-pressed={mode === id}
                onClick={() => setMode(id)}
                className={`press h-9 rounded-md px-3 text-xs font-medium tracking-wide uppercase ${
                  mode === id ? "bg-raised text-fg" : "text-muted"
                }`}
              >
                {id === "temp" ? "Temp" : "Power"}
              </button>
            ))}
          </div>
        </div>
      </div>
      <div ref={ref} className="mt-3 h-52 w-full min-w-0">
        {mod && width > 0 ? (
          <mod.TraceChart width={width} height={208} mode={mode} series={series} />
        ) : (
          <div className="h-full" />
        )}
      </div>
    </Panel>
  );
}
