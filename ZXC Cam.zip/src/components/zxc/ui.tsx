import type { ReactNode } from "react";

export function Panel({ className = "", children }: { className?: string; children: ReactNode }) {
  return <section className={`panel ${className}`}>{children}</section>;
}

export function Eyebrow({ children }: { children: ReactNode }) {
  return <p className="text-xs font-medium tracking-widest text-muted uppercase">{children}</p>;
}

export function Metric({
  label,
  value,
  unit,
  tone = "text-fg",
}: {
  label: string;
  value: string;
  unit?: string;
  tone?: string;
}) {
  return (
    <div className="min-w-0">
      <Eyebrow>{label}</Eyebrow>
      <p className={`mt-1 font-mono text-xl tabular-nums leading-none ${tone}`}>
        {value}
        {unit ? <span className="ml-1 font-sans text-xs tracking-normal text-muted">{unit}</span> : null}
      </p>
    </div>
  );
}

export function Bar({
  value,
  tone = "bg-cyan",
  label,
}: {
  value: number;
  tone?: string;
  label?: string;
}) {
  const width = Math.max(0, Math.min(100, value));
  return (
    <div
      className="h-2 overflow-hidden rounded-full bg-bg"
      role="meter"
      aria-valuenow={Math.round(width)}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={label}
    >
      <div className={`h-full rounded-full ${tone}`} style={{ width: `${width}%` }} />
    </div>
  );
}
