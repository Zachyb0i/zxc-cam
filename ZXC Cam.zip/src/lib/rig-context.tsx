import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  createLive,
  DEFAULT_SETTINGS,
  PRESETS,
  sanitizeSettings,
  snapshot,
  step,
  type Curve,
  type Effect,
  type LightKey,
  type Live,
  type Preset,
  type Profile,
  type Settings,
  type Snap,
  type ViewId,
} from "@/lib/rig";

const KEY = "zxc-cam-v1";

type RigContextValue = {
  live: Live;
  settings: Settings;
  snap: Snap;
  view: ViewId;
  setView: (view: ViewId) => void;
  setProfile: (profile: Profile) => void;
  setRigName: (name: string) => void;
  applyPreset: (preset: Exclude<Preset, "custom">) => void;
  setCurvePoint: (index: number, value: number) => void;
  setAlerts: (cpu: number, gpu: number) => void;
  setEffect: (effect: Effect) => void;
  setLightSpeed: (speed: number) => void;
  setZone: (id: keyof Settings["zones"], patch: { on?: boolean; color?: LightKey }) => void;
  setPowered: (powered: boolean) => void;
  setRpm: (mode: "low" | "med" | "high" | "custom" | "manual") => void;
  setManualDuty: (duty: number) => void;
  setHoldBand: (hold: boolean) => void;
  setRgbOn: (on: boolean) => void;
  setBrightness: (brightness: number) => void;
  resetTuning: () => void;
};

const RigContext = createContext<RigContextValue | null>(null);

export function RigProvider({ children }: { children: ReactNode }) {
  const [live, setLive] = useState<Live>(() => createLive());
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [view, setView] = useState<ViewId>("overview");
  const [hydrated, setHydrated] = useState(false);
  const settingsRef = useRef(settings);
  settingsRef.current = settings;

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setSettings(sanitizeSettings(JSON.parse(raw)));
    } catch {
      /* keep defaults */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(KEY, JSON.stringify(settings));
  }, [settings, hydrated]);

  useEffect(() => {
    const id = window.setInterval(() => {
      setLive((prev) => step(prev, settingsRef.current));
    }, 400);
    return () => window.clearInterval(id);
  }, []);

  const value = useMemo<RigContextValue>(() => {
    const snap = snapshot(live, settings);
    return {
      live,
      settings,
      snap,
      view,
      setView,
      setProfile: (profile) => setSettings((s) => ({ ...s, profile })),
      setRigName: (name) => setSettings((s) => ({ ...s, rigName: name.slice(0, 18) })),
      applyPreset: (preset) =>
        setSettings((s) => ({ ...s, manual: false, preset, curve: [...PRESETS[preset]] as Curve })),
      setCurvePoint: (index, point) =>
        setSettings((s) => {
          const curve = [...s.curve] as Curve;
          curve[index] = point;
          return { ...s, curve, preset: "custom", manual: false };
        }),
      setAlerts: (cpu, gpu) => setSettings((s) => ({ ...s, cpuAlert: cpu, gpuAlert: gpu })),
      setEffect: (effect) => setSettings((s) => ({ ...s, effect })),
      setLightSpeed: (lightSpeed) => setSettings((s) => ({ ...s, lightSpeed })),
      setZone: (id, patch) =>
        setSettings((s) => ({
          ...s,
          zones: { ...s.zones, [id]: { ...s.zones[id], ...patch } },
        })),
      setPowered: (powered) => setSettings((s) => ({ ...s, powered })),
      setRpm: (mode) =>
        setSettings((s) => {
          if (mode === "manual") return { ...s, manual: true };
          if (mode === "custom") return { ...s, manual: false, preset: "custom" };
          const preset = mode === "low" ? "silent" : mode === "med" ? "balanced" : "performance";
          return { ...s, manual: false, preset, curve: [...PRESETS[preset]] as Curve };
        }),
      setManualDuty: (manualDuty) => setSettings((s) => ({ ...s, manual: true, manualDuty })),
      setHoldBand: (holdBand) => setSettings((s) => ({ ...s, holdBand })),
      setRgbOn: (rgbOn) => setSettings((s) => ({ ...s, rgbOn })),
      setBrightness: (brightness) => setSettings((s) => ({ ...s, brightness })),
      resetTuning: () =>
        setSettings((s) => ({
          ...DEFAULT_SETTINGS,
          rigName: s.rigName,
          profile: s.profile,
          zones: {
            ring: { ...DEFAULT_SETTINGS.zones.ring },
            fans: { ...DEFAULT_SETTINGS.zones.fans },
            gpu: { ...DEFAULT_SETTINGS.zones.gpu },
            ram: { ...DEFAULT_SETTINGS.zones.ram },
          },
          curve: [...DEFAULT_SETTINGS.curve],
        })),
    };
  }, [live, settings, view]);

  return <RigContext.Provider value={value}>{children}</RigContext.Provider>;
}

export function useRig() {
  const ctx = useContext(RigContext);
  if (!ctx) throw new Error("useRig must be used inside RigProvider");
  return ctx;
}
