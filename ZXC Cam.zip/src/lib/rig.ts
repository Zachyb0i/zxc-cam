export type Profile = "idle" | "desktop" | "game" | "render" | "stress";
export type Preset = "silent" | "balanced" | "performance" | "custom";
export type LightKey = "cyan" | "ice" | "bone" | "amber" | "coral";
export type Effect = "solid" | "breathe" | "wave" | "chase";
export type Curve = [number, number, number, number, number];
export type ViewId = "overview" | "cooling" | "cpu" | "gpu" | "memory" | "storage" | "lighting";

export type Sample = {
  cpu: number;
  gpu: number;
  liquid: number;
  cpuW: number;
  gpuW: number;
};

export type Zone = { on: boolean; color: LightKey };

export type Settings = {
  rigName: string;
  profile: Profile;
  preset: Preset;
  curve: Curve;
  cpuAlert: number;
  gpuAlert: number;
  effect: Effect;
  lightSpeed: number;
  powered: boolean;
  manual: boolean;
  manualDuty: number;
  holdBand: boolean;
  rgbOn: boolean;
  brightness: number;
  zones: {
    ring: Zone;
    fans: Zone;
    gpu: Zone;
    ram: Zone;
  };
};

export type Live = {
  cpuLoad: number;
  cpuTemp: number;
  cpuPower: number;
  gpuLoad: number;
  gpuTemp: number;
  gpuPower: number;
  vram: number;
  liquid: number;
  ramUsed: number;
  fanDuty: number;
  pump: number;
  driveTemp: [number, number];
  driveAct: [number, number];
  history: Sample[];
  tick: number;
  n1: number;
  n2: number;
  anchorTemp: number;
  latchedDuty: number;
};

export const BUILD = {
  cpu: {
    name: "Ryzen 9 9950X3D",
    vendor: "AMD",
    cores: 16,
    threads: 32,
    detail: "Dual CCD · 3D V-Cache",
    tdp: 170,
  },
  gpu: {
    name: "GeForce RTX 5090",
    vendor: "NVIDIA",
    vram: 32,
    tdp: 575,
    bus: "PCIe 5.0 ×16",
    mem: "GDDR7",
  },
  board: { name: "ZXC Apex X870E", bios: "1.2.0.8" },
  ram: {
    kit: "ZXC Dominion 64 GB",
    speed: "DDR5-6400",
    timings: "CL30-39-39-76",
    sticks: 2,
    capacity: 64,
  },
  cooler: "ZXC Glacier 360",
  caseName: "ZXC Prism",
  psu: "ZXC Volt 1200W",
  psuWatts: 1200,
};

export const DRIVES = [
  {
    id: "blade",
    name: "ZXC Blade",
    capacityGb: 2000,
    used: 0.41,
    kind: "NVMe Gen5",
    iface: "PCIe 5.0 ×4",
  },
  {
    id: "vault",
    name: "ZXC Vault",
    capacityGb: 4000,
    used: 0.67,
    kind: "NVMe Gen4",
    iface: "PCIe 4.0 ×4",
  },
] as const;

export const PROFILES: { id: Profile; label: string }[] = [
  { id: "idle", label: "Idle" },
  { id: "desktop", label: "Desktop" },
  { id: "game", label: "Play" },
  { id: "render", label: "Render" },
  { id: "stress", label: "Burn" },
];

export const PRESETS: Record<Exclude<Preset, "custom">, Curve> = {
  silent: [20, 26, 34, 48, 68],
  balanced: [28, 40, 55, 75, 100],
  performance: [50, 70, 88, 100, 100],
};

export const CURVE_TEMPS = [30, 45, 60, 75, 90] as const;

export const LIGHTS: Record<LightKey, string> = {
  cyan: "var(--color-cyan)",
  ice: "color-mix(in oklab, var(--color-cyan) 48%, var(--color-fg))",
  bone: "var(--color-fg)",
  amber: "var(--color-warn)",
  coral: "var(--color-hot)",
};

export const LIGHT_KEYS: LightKey[] = ["cyan", "ice", "bone", "amber", "coral"];

const TASKS: Record<Profile, { name: string; share: number }[]> = {
  idle: [
    { name: "ZXC Cam", share: 0.42 },
    { name: "Window manager", share: 0.36 },
    { name: "System", share: 0.22 },
  ],
  desktop: [
    { name: "Browser", share: 0.48 },
    { name: "ZXC Cam", share: 0.22 },
    { name: "Music", share: 0.16 },
  ],
  game: [
    { name: "Aether Protocol", share: 0.72 },
    { name: "Overlay", share: 0.12 },
    { name: "ZXC Cam", share: 0.08 },
  ],
  render: [
    { name: "ZXC Render", share: 0.74 },
    { name: "Encoder", share: 0.16 },
    { name: "Browser", share: 0.06 },
  ],
  stress: [
    { name: "Burn-in CPU", share: 0.58 },
    { name: "Burn-in GPU", share: 0.34 },
    { name: "ZXC Cam", share: 0.05 },
  ],
};

const TARGET: Record<
  Profile,
  { cpuL: number; gpuL: number; vram: number; ram: number; d0: number; d1: number }
> = {
  idle: { cpuL: 0.04, gpuL: 0.02, vram: 1.8, ram: 12.4, d0: 0.03, d1: 0.01 },
  desktop: { cpuL: 0.14, gpuL: 0.08, vram: 4.6, ram: 21.6, d0: 0.1, d1: 0.04 },
  game: { cpuL: 0.46, gpuL: 0.95, vram: 18.4, ram: 28.2, d0: 0.18, d1: 0.06 },
  render: { cpuL: 0.97, gpuL: 0.48, vram: 10.8, ram: 49.5, d0: 0.62, d1: 0.16 },
  stress: { cpuL: 1, gpuL: 0.99, vram: 27.6, ram: 57.4, d0: 0.78, d1: 0.28 },
};

export const DEFAULT_SETTINGS: Settings = {
  rigName: "FORGE-01",
  profile: "desktop",
  preset: "balanced",
  curve: [...PRESETS.balanced],
  cpuAlert: 90,
  gpuAlert: 85,
  effect: "breathe",
  lightSpeed: 1,
  powered: true,
  manual: false,
  manualDuty: 35,
  holdBand: true,
  rgbOn: true,
  brightness: 80,
  zones: {
    ring: { on: true, color: "cyan" },
    fans: { on: true, color: "cyan" },
    gpu: { on: true, color: "coral" },
    ram: { on: true, color: "ice" },
  },
};

function seedHistory(): Sample[] {
  const out: Sample[] = [];
  for (let i = 0; i < 72; i++) {
    const w = Math.sin(i / 8) * 1.35;
    out.push({
      cpu: 43.2 + w,
      gpu: 36.4 + w * 0.5,
      liquid: 31.2 + w * 0.22,
      cpuW: 48 + w * 2.4,
      gpuW: 52 + w * 3,
    });
  }
  return out;
}

const SEEDED = seedHistory();

export function createLive(): Live {
  const history = SEEDED.map((s) => ({ ...s }));
  const last = history[history.length - 1]!;
  return {
    cpuLoad: 0.14,
    cpuTemp: last.cpu,
    cpuPower: last.cpuW,
    gpuLoad: 0.08,
    gpuTemp: last.gpu,
    gpuPower: last.gpuW,
    vram: 4.6,
    liquid: last.liquid,
    ramUsed: 21.6,
    fanDuty: 38,
    pump: 52,
    driveTemp: [35.5, 33.4],
    driveAct: [0.08, 0.03],
    history,
    tick: 72,
    n1: 0,
    n2: 0,
    anchorTemp: last.cpu,
    latchedDuty: 38,
  };
}

export function clamp(n: number, a: number, b: number) {
  return Math.min(b, Math.max(a, n));
}

function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

export function sampleCurve(curve: Curve, temp: number) {
  const pts = CURVE_TEMPS;
  if (temp <= pts[0]) return curve[0];
  if (temp >= pts[4]) return curve[4];
  for (let i = 0; i < 4; i++) {
    const a = pts[i]!;
    const b = pts[i + 1]!;
    if (temp <= b) {
      const t = (temp - a) / (b - a);
      return curve[i]! + (curve[i + 1]! - curve[i]!) * t;
    }
  }
  return curve[4];
}

export function step(live: Live, settings: Settings): Live {
  const t = TARGET[settings.profile];
  const n1 = live.n1 * 0.82 + (Math.random() - 0.5) * 0.18;
  const n2 = live.n2 * 0.82 + (Math.random() - 0.5) * 0.18;
  const cpuLoad = clamp(lerp(live.cpuLoad, t.cpuL + n1 * 0.035, 0.22), 0.012, 1);
  const gpuLoad = clamp(lerp(live.gpuLoad, t.gpuL + n2 * 0.03, 0.18), 0, 1);
  let dutyCmd = sampleCurve(settings.curve, live.cpuTemp);
  let anchorTemp = live.anchorTemp;
  let latchedDuty = live.latchedDuty;
  if (!settings.powered) {
    dutyCmd = 0;
  } else if (settings.manual) {
    dutyCmd = settings.manualDuty;
    latchedDuty = dutyCmd;
  } else if (settings.holdBand && Math.abs(live.cpuTemp - anchorTemp) < 3) {
    dutyCmd = latchedDuty;
  } else {
    anchorTemp = live.cpuTemp;
    latchedDuty = dutyCmd;
  }
  const fanDuty = lerp(live.fanDuty, dutyCmd, 0.2);
  const relief = clamp((fanDuty - 25) / 75, 0, 1) * 14;
  const cpuTarget = 36 + cpuLoad * 50 + gpuLoad * 6 + n1 * 0.45 - relief;
  const gpuTarget = 32 + gpuLoad * 52 + cpuLoad * 3 + n2 * 0.4 - relief * 0.35;
  const cpuTemp = clamp(lerp(live.cpuTemp, cpuTarget, 0.065), 28, 102);
  const gpuTemp = clamp(lerp(live.gpuTemp, gpuTarget, 0.07), 26, 102);
  const liquid = clamp(lerp(live.liquid, 27 + (cpuTemp - 30) * 0.4, 0.045), 24, 60);
  const cpuPower = clamp(lerp(live.cpuPower, 16 + cpuLoad * 228, 0.2), 8, 280);
  const gpuPower = clamp(lerp(live.gpuPower, 12 + gpuLoad * 565, 0.18), 8, 600);
  const vram = clamp(lerp(live.vram, t.vram, 0.08), 0.4, BUILD.gpu.vram);
  const ramUsed = clamp(lerp(live.ramUsed, t.ram, 0.06), 4, BUILD.ram.capacity - 0.4);
  const pump = clamp(lerp(live.pump, 42 + (liquid - 28) * 2.6, 0.08), 38, 100);
  const driveAct: [number, number] = [
    clamp(lerp(live.driveAct[0], t.d0, 0.2), 0, 1),
    clamp(lerp(live.driveAct[1], t.d1, 0.16), 0, 1),
  ];
  const driveTemp: [number, number] = [
    clamp(32 + driveAct[0] * 16 + (cpuTemp - 40) * 0.08, 28, 72),
    clamp(31 + driveAct[1] * 12 + (cpuTemp - 40) * 0.05, 28, 68),
  ];
  const sample: Sample = { cpu: cpuTemp, gpu: gpuTemp, liquid, cpuW: cpuPower, gpuW: gpuPower };
  return {
    cpuLoad,
    cpuTemp,
    cpuPower,
    gpuLoad,
    gpuTemp,
    gpuPower,
    vram,
    liquid,
    ramUsed,
    fanDuty,
    pump,
    driveTemp,
    driveAct,
    history: live.history.slice(1).concat(sample),
    tick: live.tick + 1,
    n1,
    n2,
    anchorTemp,
    latchedDuty,
  };
}

function cpuGhz(load: number, temp: number) {
  let ghz: number;
  if (load < 0.08) ghz = 3.25 + load * 6;
  else if (load < 0.35) ghz = 5.15 + (0.35 - load) * 1.5;
  else ghz = 5.22 - (load - 0.35) * 0.48;
  if (temp > 93) ghz -= (temp - 93) * 0.07;
  return clamp(ghz, 2.6, 5.7);
}

function fanRpm(duty: number, max: number, tick: number, phase: number) {
  const wobble = Math.sin(tick / 5 + phase) * 14;
  return Math.max(0, Math.round((duty / 100) * max + wobble));
}

export function snapshot(live: Live, settings: Settings) {
  const cpuClock = cpuGhz(live.cpuLoad, live.cpuTemp);
  const gpuClock =
    live.gpuLoad < 0.08
      ? 210 + live.gpuLoad * 800
      : clamp(2520 + live.gpuLoad * 220 - Math.max(0, live.gpuTemp - 84) * 22, 400, 2790);
  const memClock = live.gpuLoad < 0.08 ? 405 : 2235;
  const hotspot = live.gpuTemp + 8 + live.gpuLoad * 8;
  const memJunction = live.gpuTemp + 3 + live.gpuLoad * 12;
  const vcore = clamp(1.02 + live.cpuLoad * 0.27 - Math.max(0, live.cpuTemp - 90) * 0.01, 0.9, 1.38);
  const cores = Array.from({ length: 16 }, (_, i) => {
    const wave = Math.sin(live.tick / 7 + i * 0.65);
    const load = clamp(live.cpuLoad + (i < 8 ? 0.05 : -0.03) + wave * 0.035, 0.01, 1);
    const temp = live.cpuTemp + (i < 8 ? 3.4 : -1.6) + wave * 1.15;
    const clock = clamp(cpuClock + (i % 4) * 0.015 - (temp > 94 ? 0.12 : 0), 2.4, 5.75);
    return { index: i, load, temp, clock, ccd: i < 8 ? 0 : 1 };
  });
  const hottest = cores.reduce((best, core) => (core.temp > best.temp ? core : best), cores[0]!);
  const fans = [
    { id: "r1", name: "Radiator 1", role: "Intake", rpm: fanRpm(live.fanDuty, 1800, live.tick, 0), max: 1800 },
    { id: "r2", name: "Radiator 2", role: "Intake", rpm: fanRpm(live.fanDuty, 1800, live.tick, 1.1), max: 1800 },
    { id: "r3", name: "Radiator 3", role: "Intake", rpm: fanRpm(live.fanDuty, 1800, live.tick, 2.2), max: 1800 },
    {
      id: "ex",
      name: "Rear exhaust",
      role: "Exhaust",
      rpm: fanRpm(live.fanDuty * 0.92, 1600, live.tick, 0.5),
      max: 1600,
    },
  ];
  const gpuFanOn = live.gpuTemp > 50 || live.gpuLoad > 0.2;
  const gpuFanDuty = gpuFanOn ? clamp((live.gpuTemp - 42) / 42, 0.28, 1) : 0;
  const gpuFanRpm = gpuFanOn ? Math.round(gpuFanDuty * 2200 + Math.sin(live.tick / 4) * 18) : 0;
  const pumpRpm = Math.round(1450 + (live.pump / 100) * 1500);
  const sysPower = live.cpuPower + live.gpuPower + 28 + live.ramUsed * 0.12;
  const tasks = TASKS[settings.profile].map((task, i) => {
    const wobble = 0.92 + 0.08 * Math.sin(live.tick / 6 + i);
    return {
      name: task.name,
      cpu: clamp(task.share * live.cpuLoad * 100 * wobble, 0, 100),
    };
  });
  const drives = DRIVES.map((drive, i) => {
    const act = live.driveAct[i]!;
    const swing = 0.55 + 0.45 * (0.5 + 0.5 * Math.sin(live.tick / 8 + i));
    const scale = i === 0 ? 1 : 0.62;
    return {
      ...drive,
      temp: live.driveTemp[i]!,
      activity: act,
      read: act * 4200 * scale,
      write: act * 2800 * scale * swing,
    };
  });
  const uptime = 4 * 3600 + 12 * 60 + live.tick * 0.4;
  return {
    cpuClock,
    gpuClock,
    memClock,
    hotspot,
    memJunction,
    vcore,
    cores,
    hottest,
    fans,
    gpuFanOn,
    gpuFanRpm,
    gpuFanDuty,
    pumpRpm,
    sysPower,
    tasks,
    drives,
    uptime,
    delta: live.cpuTemp - live.history[0]!.cpu,
    gpuDelta: live.gpuTemp - live.history[0]!.gpu,
  };
}

export type Snap = ReturnType<typeof snapshot>;

export function formatUptime(seconds: number) {
  const s = Math.max(0, Math.floor(seconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${h}h ${String(m).padStart(2, "0")}m ${String(sec).padStart(2, "0")}s`;
}

export function toneOf(temp: number): "cyan" | "warn" | "hot" {
  if (temp <= 47) return "cyan";
  if (temp <= 78) return "warn";
  return "hot";
}

export function toneStroke(temp: number) {
  const tone = toneOf(temp);
  if (tone === "cyan") return "var(--color-cyan)";
  if (tone === "warn") return "var(--color-warn)";
  return "var(--color-hot)";
}

export function toneText(temp: number) {
  const tone = toneOf(temp);
  if (tone === "cyan") return "text-cyan";
  if (tone === "warn") return "text-warn";
  return "text-hot";
}

export function toneBar(temp: number) {
  const tone = toneOf(temp);
  if (tone === "cyan") return "bg-cyan";
  if (tone === "warn") return "bg-warn";
  return "bg-hot";
}

const PROFILES_SET = new Set<string>(PROFILES.map((p) => p.id));
const PRESET_SET = new Set<string>(["silent", "balanced", "performance", "custom"]);
const EFFECT_SET = new Set<string>(["solid", "breathe", "wave", "chase"]);
const LIGHT_SET = new Set<string>(LIGHT_KEYS);

function zone(value: unknown, fallback: Zone): Zone {
  if (!value || typeof value !== "object") return fallback;
  const z = value as Partial<Zone>;
  return {
    on: typeof z.on === "boolean" ? z.on : fallback.on,
    color: typeof z.color === "string" && LIGHT_SET.has(z.color) ? (z.color as LightKey) : fallback.color,
  };
}

export function sanitizeSettings(raw: unknown): Settings {
  const base = DEFAULT_SETTINGS;
  if (!raw || typeof raw !== "object") return base;
  const p = raw as Partial<Settings>;
  const curveOk =
    Array.isArray(p.curve) &&
    p.curve.length === 5 &&
    p.curve.every((n) => typeof n === "number" && n >= 0 && n <= 100);
  const zones = (p.zones ?? {}) as Partial<Settings["zones"]>;
  return {
    rigName:
      typeof p.rigName === "string" && p.rigName.trim()
        ? p.rigName.trim().slice(0, 18)
        : base.rigName,
    profile: typeof p.profile === "string" && PROFILES_SET.has(p.profile) ? (p.profile as Profile) : base.profile,
    preset: typeof p.preset === "string" && PRESET_SET.has(p.preset) ? (p.preset as Preset) : base.preset,
    curve: curveOk ? (p.curve as Curve) : base.curve,
    cpuAlert: typeof p.cpuAlert === "number" ? clamp(p.cpuAlert, 70, 105) : base.cpuAlert,
    gpuAlert: typeof p.gpuAlert === "number" ? clamp(p.gpuAlert, 70, 105) : base.gpuAlert,
    effect: typeof p.effect === "string" && EFFECT_SET.has(p.effect) ? (p.effect as Effect) : base.effect,
    lightSpeed: typeof p.lightSpeed === "number" ? clamp(p.lightSpeed, 0.5, 2) : base.lightSpeed,
    powered: typeof p.powered === "boolean" ? p.powered : base.powered,
    manual: typeof p.manual === "boolean" ? p.manual : base.manual,
    manualDuty: typeof p.manualDuty === "number" ? clamp(p.manualDuty, 0, 100) : base.manualDuty,
    holdBand: typeof p.holdBand === "boolean" ? p.holdBand : base.holdBand,
    rgbOn: typeof p.rgbOn === "boolean" ? p.rgbOn : base.rgbOn,
    brightness: typeof p.brightness === "number" ? clamp(p.brightness, 0, 100) : base.brightness,
    zones: {
      ring: zone(zones.ring, base.zones.ring),
      fans: zone(zones.fans, base.zones.fans),
      gpu: zone(zones.gpu, base.zones.gpu),
      ram: zone(zones.ram, base.zones.ram),
    },
  };
}
