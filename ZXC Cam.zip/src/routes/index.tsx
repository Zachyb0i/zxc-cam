import { createFileRoute } from "@tanstack/react-router";
import { RigProvider } from "@/lib/rig-context";
import { Shell } from "@/components/zxc/shell";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return (
    <RigProvider>
      <Shell />
    </RigProvider>
  );
}
